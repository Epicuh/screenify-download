#!/usr/bin/env python3
import os
import signal
import time

import dbus
import dbus.mainloop.glib
import dbus.service
from gi.repository import GLib


AGENT_INTERFACE = 'org.bluez.Agent1'
AGENT_PATH = '/com/screenify/BluetoothAgent'
CAPABILITY = 'NoInputNoOutput'
PAIRING_WINDOW_PATH = os.environ.get(
    'SCREENIFY_BLUETOOTH_PAIRING_WINDOW',
    '/run/screenify/bluetooth-pairing-until'
)


class Rejected(dbus.exceptions.DBusException):
    _dbus_error_name = 'org.bluez.Error.Rejected'


class ScreenifyBluetoothAgent(dbus.service.Object):
    def __init__(self, bus):
        super().__init__(bus, AGENT_PATH)
        self.bus = bus

    def log(self, message):
        print('[screenify-bluetooth-agent] {}'.format(message), flush=True)

    def pairing_window_open(self):
        try:
            with open(PAIRING_WINDOW_PATH, 'r', encoding='utf-8') as handle:
                return float(handle.read().strip()) > time.time()
        except (OSError, ValueError):
            return False

    def known_device(self, device):
        try:
            properties = dbus.Interface(
                self.bus.get_object('org.bluez', device),
                'org.freedesktop.DBus.Properties'
            )
            values = properties.GetAll('org.bluez.Device1')
            return bool(values.get('Paired')) and bool(values.get('Trusted'))
        except dbus.DBusException:
            return False

    def require_pairing_window(self, device, allow_known=False):
        if self.pairing_window_open() or (allow_known and self.known_device(device)):
            return
        self.log('rejecting Bluetooth request outside the pairing window')
        raise Rejected('Screenify Bluetooth pairing is closed')

    @dbus.service.method(AGENT_INTERFACE, in_signature='', out_signature='')
    def Release(self):
        self.log('released by BlueZ')

    @dbus.service.method(AGENT_INTERFACE, in_signature='o', out_signature='s')
    def RequestPinCode(self, device):
        self.require_pairing_window(device)
        self.log('accepting PIN pairing for {}'.format(device))
        return '0000'

    @dbus.service.method(AGENT_INTERFACE, in_signature='o', out_signature='u')
    def RequestPasskey(self, device):
        self.require_pairing_window(device)
        self.log('accepting passkey pairing for {}'.format(device))
        return dbus.UInt32(0)

    @dbus.service.method(AGENT_INTERFACE, in_signature='os', out_signature='')
    def DisplayPinCode(self, device, pin_code):
        self.log('display PIN requested for {}'.format(device))

    @dbus.service.method(AGENT_INTERFACE, in_signature='ouq', out_signature='')
    def DisplayPasskey(self, device, passkey, entered):
        pass

    @dbus.service.method(AGENT_INTERFACE, in_signature='ou', out_signature='')
    def RequestConfirmation(self, device, passkey):
        self.require_pairing_window(device)
        self.log('confirming pairing for {}'.format(device))

    @dbus.service.method(AGENT_INTERFACE, in_signature='o', out_signature='')
    def RequestAuthorization(self, device):
        self.require_pairing_window(device, allow_known=True)
        self.log('authorizing pairing for {}'.format(device))

    @dbus.service.method(AGENT_INTERFACE, in_signature='os', out_signature='')
    def AuthorizeService(self, device, uuid):
        self.require_pairing_window(device, allow_known=True)
        self.log('authorizing service {} for {}'.format(uuid, device))

    @dbus.service.method(AGENT_INTERFACE, in_signature='', out_signature='')
    def Cancel(self):
        self.log('pairing request cancelled')


def main():
    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
    bus = dbus.SystemBus()
    agent = ScreenifyBluetoothAgent(bus)
    manager = dbus.Interface(
        bus.get_object('org.bluez', '/org/bluez'),
        'org.bluez.AgentManager1'
    )
    manager.RegisterAgent(AGENT_PATH, CAPABILITY)
    manager.RequestDefaultAgent(AGENT_PATH)
    agent.log('registered as the default {} agent'.format(CAPABILITY))

    loop = GLib.MainLoop()

    def stop(*_args):
        try:
            manager.UnregisterAgent(AGENT_PATH)
        except dbus.DBusException:
            pass
        loop.quit()

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    loop.run()


if __name__ == '__main__':
    main()
