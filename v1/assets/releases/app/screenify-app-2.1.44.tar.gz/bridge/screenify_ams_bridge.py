#!/usr/bin/env python3
import json
import os
import signal
import sys
import time
import urllib.error
import urllib.request

import dbus
import dbus.mainloop.glib
from gi.repository import GLib


AMS_SERVICE_UUID = '89d3502b-0f36-433a-8ef4-c502ad55f8dc'
AMS_ENTITY_UPDATE_UUID = '2f7cabce-808d-411f-9a0c-bb92ba96c102'
AMS_ENTITY_ATTRIBUTE_UUID = 'c6b2f38c-23ab-46d8-a6ab-a3a870bbd5d7'

ENTITY_PLAYER = 0
ENTITY_TRACK = 2
PLAYER_ATTR_NAME = 0
PLAYER_ATTR_PLAYBACK_INFO = 1
TRACK_ATTR_ARTIST = 0
TRACK_ATTR_ALBUM = 1
TRACK_ATTR_TITLE = 2
TRACK_ATTR_DURATION = 3

BRIDGE_URL = os.environ.get('SCREENIFY_BRIDGE_URL', 'http://127.0.0.1:8787').rstrip('/')
AMS_STATE_PATH = os.environ.get(
    'SCREENIFY_AMS_STATE_PATH',
    os.path.expanduser('~/.screenify-ams-device.json')
)
WIFI_SETUP_MARKER = os.environ.get(
    'SCREENIFY_WIFI_SETUP_MARKER',
    '/run/screenify-wifi-setup/setup-mode'
)
BLUETOOTH_PAIRING_WINDOW = os.environ.get(
    'SCREENIFY_BLUETOOTH_PAIRING_WINDOW',
    '/run/screenify/bluetooth-pairing-until'
)
BLUETOOTH_ALIAS = os.environ.get(
    'SCREENIFY_BLUETOOTH_ALIAS',
    'Screenify'
).strip() or 'Screenify'
POST_PATH = '/api/ams/state'
HEARTBEAT_MS = 250
SCAN_RETRY_MS = 3500
CONNECT_RETRY_MS = 2500
SNAPSHOT_REFRESH_MS = 1000
STATE_POST_DEBOUNCE_MS = 80
PLAYBACK_POST_DEBOUNCE_MS = 40
TRACK_METADATA_SETTLE_MS = 260
FAST_TRACK_SETTLE_MS = 20
PLAYBACK_RESTART_SUPPRESS_MS = 2500
PLAYBACK_RESTART_PROGRESS_MS = 1500
PLAYBACK_RESTART_MIN_OLD_PROGRESS_MS = 5000
COMPLETED_TRACK_STALE_MS = 1800
AMS_RESET_COOLDOWN_MS = 3500


class ScreenifyAmsBridge:
    def __init__(self):
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        self.bus = dbus.SystemBus()
        self.loop = GLib.MainLoop()
        self.objects = {}
        self.adapter_path = '/org/bluez/hci0'
        self.device_path = ''
        self.device_name = 'iPhone'
        self.entity_update_path = ''
        self.entity_attribute_path = ''
        self.update_sequence = 0
        self.connected = False
        self.connecting = False
        self.failed_until = {}
        self.last_post_signature = ''
        self.last_connected_post_at = 0.0
        self.last_ams_subscribe_attempt_at = 0.0
        self.ams_monitor_requested = False
        self.last_snapshot_request_at = 0.0
        self.last_ams_event_at = 0.0
        self.last_ams_established_at = 0.0
        self.last_ams_reset_at = 0.0
        self.completed_stale_started_at = 0.0
        self.pending_state_post_timer = 0
        self.last_elapsed_ms = 0
        self.last_elapsed_monotonic = 0.0
        self.track = {
            'title': '',
            'artist': '',
            'album': '',
            'durationMs': 0,
            'sourceApp': 'iPhone',
            'playing': False
        }
        self.display_track = None
        self.track_attrs_seen = set()
        self.track_metadata_settled = False
        self.track_dirty = False
        self.track_last_changed_at = 0.0
        self.track_snapshot_requested = False
        self.playback_restart_pending_at = 0.0

        self.bus.add_signal_receiver(
            self.on_properties_changed,
            dbus_interface='org.freedesktop.DBus.Properties',
            signal_name='PropertiesChanged',
            path_keyword='path'
        )

    def log(self, message):
        print('[screenify-ams]', message, flush=True)

    def reset_track_metadata(self):
        source_app = self.track.get('sourceApp') or 'iPhone'
        self.track = {
            'title': '',
            'artist': '',
            'album': '',
            'durationMs': 0,
            'sourceApp': source_app,
            'playing': False
        }
        self.last_elapsed_ms = 0
        self.last_elapsed_monotonic = time.monotonic()
        self.last_post_signature = ''
        self.completed_stale_started_at = 0.0
        self.display_track = None
        self.track_attrs_seen = set()
        self.track_metadata_settled = False
        self.track_dirty = False
        self.track_last_changed_at = 0.0
        self.track_snapshot_requested = False
        self.playback_restart_pending_at = 0.0

    def load_last_device(self):
        try:
            with open(AMS_STATE_PATH, 'r', encoding='utf-8') as handle:
                payload = json.load(handle)
            self.device_path = str(payload.get('devicePath') or '')
            self.device_name = str(payload.get('deviceName') or 'iPhone')
        except (OSError, json.JSONDecodeError):
            self.device_path = ''

    def save_last_device(self):
        if not self.device_path:
            return
        payload = {
            'devicePath': self.device_path,
            'deviceName': self.device_name,
            'updatedAt': int(time.time())
        }
        try:
            with open(AMS_STATE_PATH, 'w', encoding='utf-8') as handle:
                json.dump(payload, handle)
        except OSError as error:
            self.log('failed to save state: {}'.format(error))

    def proxy(self, path, interface):
        return dbus.Interface(self.bus.get_object('org.bluez', path), interface)

    def properties(self, path):
        return self.proxy(path, 'org.freedesktop.DBus.Properties')

    def refresh_objects(self):
        manager = dbus.Interface(
            self.bus.get_object('org.bluez', '/'),
            'org.freedesktop.DBus.ObjectManager'
        )
        self.objects = manager.GetManagedObjects()
        return self.objects

    def set_adapter_idle_mode(self):
        props = self.properties(self.adapter_path)
        props.Set('org.bluez.Adapter1', 'Powered', dbus.Boolean(True))
        props.Set('org.bluez.Adapter1', 'Alias', dbus.String(BLUETOOTH_ALIAS))
        remaining = self.bluetooth_pairing_seconds_remaining()
        props.Set(
            'org.bluez.Adapter1',
            'PairableTimeout',
            dbus.UInt32(remaining)
        )
        props.Set(
            'org.bluez.Adapter1',
            'DiscoverableTimeout',
            dbus.UInt32(remaining)
        )
        pairing_open = remaining > 0
        props.Set('org.bluez.Adapter1', 'Pairable', dbus.Boolean(pairing_open))
        props.Set('org.bluez.Adapter1', 'Discoverable', dbus.Boolean(pairing_open))

    def bluetooth_pairing_seconds_remaining(self):
        try:
            with open(BLUETOOTH_PAIRING_WINDOW, 'r', encoding='utf-8') as handle:
                deadline = float(handle.read().strip())
            return max(0, min(300, int(deadline - time.time())))
        except (OSError, ValueError):
            return 0

    def set_adapter_connected_mode(self):
        props = self.properties(self.adapter_path)
        props.Set('org.bluez.Adapter1', 'Powered', dbus.Boolean(True))
        props.Set('org.bluez.Adapter1', 'Alias', dbus.String(BLUETOOTH_ALIAS))
        props.Set('org.bluez.Adapter1', 'Pairable', dbus.Boolean(False))
        props.Set('org.bluez.Adapter1', 'Discoverable', dbus.Boolean(False))

    def wifi_setup_active(self):
        return os.path.exists(WIFI_SETUP_MARKER)

    def set_adapter_provisioning_mode(self):
        props = self.properties(self.adapter_path)
        props.Set('org.bluez.Adapter1', 'Powered', dbus.Boolean(True))
        try:
            self.proxy(
                self.adapter_path,
                'org.bluez.Adapter1'
            ).StopDiscovery()
        except Exception:
            pass
        for name in ('Pairable', 'Discoverable'):
            try:
                props.Set('org.bluez.Adapter1', name, dbus.Boolean(False))
            except Exception:
                pass

    def set_adapter_locked_mode(self):
        props = self.properties(self.adapter_path)
        for name in ('Pairable', 'Discoverable'):
            try:
                props.Set('org.bluez.Adapter1', name, dbus.Boolean(False))
            except Exception:
                pass
        try:
            props.Set('org.bluez.Adapter1', 'Powered', dbus.Boolean(False))
        except Exception:
            pass

    def get_source_policy(self):
        try:
            request = urllib.request.Request(BRIDGE_URL + '/api/state', method='GET')
            with urllib.request.urlopen(request, timeout=2) as response:
                payload = json.loads(response.read().decode('utf-8'))
            return payload.get('source') or {}
        except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError):
            return {}

    def current_owner(self):
        return str(self.get_source_policy().get('owner') or 'idle')

    def disconnect_current_device(self, reason):
        if not self.device_path:
            return
        self.log('disconnecting iPhone because {}'.format(reason))
        try:
            self.proxy(self.device_path, 'org.bluez.Device1').Disconnect()
        except Exception:
            pass
        self.connected = False
        self.entity_update_path = ''
        self.entity_attribute_path = ''
        self.ams_monitor_requested = False
        self.post_disconnect()

    def get_device_props(self, path):
        return self.objects.get(path, {}).get('org.bluez.Device1', {})

    def is_iphone_candidate(self, path, props):
        alias = str(props.get('Alias') or props.get('Name') or '').lower()
        uuids = [str(value).lower() for value in props.get('UUIDs', [])]
        recently_seen = (
            props.get('RSSI') is not None
            or bool(props.get('Connected'))
            or bool(props.get('ServicesResolved'))
        )
        if AMS_SERVICE_UUID in uuids:
            return True
        if recently_seen and ('iphone' in alias or 'ipad' in alias):
            return True
        return bool(
            recently_seen
            and props.get('Paired')
            and props.get('Trusted')
            and 'phone' in alias
        )

    def find_iphone_candidates(self, connected_only=False):
        self.refresh_objects()
        candidates = []
        now = time.time()
        for path, interfaces in self.objects.items():
            if self.failed_until.get(path, 0) > now:
                continue
            props = interfaces.get('org.bluez.Device1')
            if not props or not self.is_iphone_candidate(path, props):
                continue
            if connected_only and not bool(props.get('Connected')):
                continue
            candidates.append((path, props))

        if self.device_path:
            candidates.sort(key=lambda item: 0 if item[0] == self.device_path else 1)
        return candidates

    def has_connected_apple_device(self):
        return any(
            bool(props.get('Paired'))
            for _path, props in self.find_iphone_candidates(connected_only=True)
        )

    def find_ams_characteristics(self, device_path):
        self.refresh_objects()
        entity_update = ''
        entity_attribute = ''

        for path, interfaces in self.objects.items():
            if not path.startswith(device_path):
                continue
            char_props = interfaces.get('org.bluez.GattCharacteristic1')
            if not char_props:
                continue
            uuid = str(char_props.get('UUID') or '').lower()
            if uuid == AMS_ENTITY_UPDATE_UUID:
                entity_update = path
            elif uuid == AMS_ENTITY_ATTRIBUTE_UUID:
                entity_attribute = path

        return entity_update, entity_attribute

    def write_entity_update_request(self, entity, attributes):
        if not self.entity_update_path:
            return

        value = [dbus.Byte(entity)]
        value.extend(dbus.Byte(attribute) for attribute in attributes)
        char = self.proxy(self.entity_update_path, 'org.bluez.GattCharacteristic1')
        char.WriteValue(dbus.Array(value, signature='y'), dbus.Dictionary({}, signature='sv'))

    def request_full_snapshot(self):
        self.last_snapshot_request_at = time.monotonic()
        self.write_entity_update_request(
            ENTITY_PLAYER,
            [PLAYER_ATTR_NAME, PLAYER_ATTR_PLAYBACK_INFO]
        )
        self.write_entity_update_request(
            ENTITY_TRACK,
            [
                TRACK_ATTR_ARTIST,
                TRACK_ATTR_ALBUM,
                TRACK_ATTR_TITLE,
                TRACK_ATTR_DURATION
            ]
        )

    def start_notify(self):
        char = self.proxy(self.entity_update_path, 'org.bluez.GattCharacteristic1')
        char.StartNotify()

    def ams_ready(self):
        return bool(
            self.entity_update_path
            and self.entity_attribute_path
            and self.ams_monitor_requested
        )

    def subscribe_ams(self):
        if not self.device_path:
            return False

        now = time.monotonic()
        if now - self.last_ams_subscribe_attempt_at < 2:
            return False
        self.last_ams_subscribe_attempt_at = now

        entity_update, entity_attribute = self.find_ams_characteristics(self.device_path)
        if not entity_update or not entity_attribute:
            return False

        self.entity_update_path = entity_update
        self.entity_attribute_path = entity_attribute

        try:
            self.start_notify()
        except Exception as error:
            error_text = str(error).lower()
            if 'already' not in error_text and 'in progress' not in error_text:
                self.log('AMS notify retry needed: {}'.format(error))
                self.entity_update_path = ''
                self.entity_attribute_path = ''
                return False

        try:
            self.request_full_snapshot()
            self.ams_monitor_requested = True
        except Exception as error:
            self.ams_monitor_requested = False
            self.log('AMS monitor request retry needed: {}'.format(error))
            return False

        self.last_ams_established_at = time.monotonic()
        self.log('AMS metadata sync established for {}'.format(self.device_name))
        return True

    def request_snapshot_if_due(self, force=False):
        if not self.ams_ready():
            return False

        now = time.monotonic()
        if (
            not force
            and now - self.last_snapshot_request_at < SNAPSHOT_REFRESH_MS / 1000.0
        ):
            return False

        try:
            self.request_full_snapshot()
            return True
        except Exception as error:
            self.log('AMS snapshot refresh retry needed: {}'.format(error))
            return False

    def reset_ams_subscription(self, reason):
        self.log('resetting AMS subscription: {}'.format(reason))
        try:
            if self.entity_update_path:
                self.proxy(
                    self.entity_update_path,
                    'org.bluez.GattCharacteristic1'
                ).StopNotify()
        except Exception:
            pass

        self.entity_update_path = ''
        self.entity_attribute_path = ''
        self.ams_monitor_requested = False
        self.last_ams_subscribe_attempt_at = 0.0
        self.last_ams_established_at = 0.0

    def connect_device(self, path, props):
        if self.connecting:
            return False

        self.connecting = True
        self.log('connecting to {}'.format(str(props.get('Alias') or props.get('Name') or path)))

        try:
            device = self.proxy(path, 'org.bluez.Device1')
            if not bool(props.get('Connected')):
                self.log('waiting for iPhone to initiate Bluetooth connection')
                return False

            if not bool(props.get('Paired')):
                self.log('waiting for Bluetooth pairing to finish')
                self.set_adapter_idle_mode()
                return False

            self.device_path = path
            self.device_name = str(props.get('Alias') or props.get('Name') or 'iPhone')
            self.connected = True
            self.set_adapter_connected_mode()
            try:
                self.properties(path).Set(
                    'org.bluez.Device1',
                    'Trusted',
                    dbus.Boolean(True)
                )
            except Exception:
                pass
            self.save_last_device()
            self.post_connected(force=True)
            self.subscribe_ams()
            self.log('Bluetooth connected to {}'.format(self.device_name))
            return True
        except Exception as error:
            self.log('connect failed: {}'.format(error))
            self.failed_until[path] = time.time() + 30
            if not self.connected:
                self.set_adapter_idle_mode()
            return False
        finally:
            self.connecting = False

    def scan_once(self):
        if self.wifi_setup_active():
            self.set_adapter_provisioning_mode()
            return False
        if self.current_owner() != 'idle':
            return False

        candidates = self.find_iphone_candidates(connected_only=True)
        if candidates:
            self.set_adapter_connected_mode()
        elif self.bluetooth_pairing_seconds_remaining() > 0:
            self.set_adapter_idle_mode()
            adapter = self.proxy(self.adapter_path, 'org.bluez.Adapter1')
            try:
                adapter.StartDiscovery()
            except Exception:
                pass
        else:
            self.set_adapter_idle_mode()

        for path, props in candidates:
            if self.connect_device(path, props):
                return True

        return False

    def on_properties_changed(self, interface, changed, invalidated, path=None):
        if interface == 'org.bluez.Device1' and path == self.device_path:
            if 'Connected' in changed:
                if not bool(changed['Connected']):
                    self.log('iPhone disconnected')
                    self.connected = False
                    self.entity_update_path = ''
                    self.entity_attribute_path = ''
                    self.ams_monitor_requested = False
                    self.set_adapter_idle_mode()
                    self.post_disconnect()
                elif self.current_owner() == 'idle':
                    self.failed_until.pop(path, None)
                    self.set_adapter_connected_mode()
                    GLib.timeout_add(500, self.connect_connected_device, path)
            return

        if interface == 'org.bluez.Device1' and (
            'Connected' in changed or 'Paired' in changed
        ):
            self.refresh_objects()
            props = self.get_device_props(path)
            if (
                bool(props.get('Connected'))
                and bool(props.get('Paired'))
                and self.current_owner() == 'idle'
            ):
                self.failed_until.pop(path, None)
                self.set_adapter_connected_mode()
                GLib.timeout_add(500, self.connect_connected_device, path)
            elif self.current_owner() == 'idle':
                self.set_adapter_idle_mode()
            return

        if (
            interface != 'org.bluez.GattCharacteristic1'
            or path != self.entity_update_path
            or 'Value' not in changed
        ):
            return

        self.handle_entity_update([int(byte) for byte in changed['Value']])

    def connect_connected_device(self, path):
        self.refresh_objects()
        props = self.get_device_props(path)
        if props and self.is_iphone_candidate(path, props) and bool(props.get('Connected')):
            self.connect_device(path, props)
        return False

    def handle_entity_update(self, value):
        if len(value) < 3:
            return

        before_track_id = self.track_id()
        entity = value[0]
        attribute = value[1]
        text = bytes(value[3:]).decode('utf-8', errors='replace').strip()
        text = text.rstrip('\x00')
        now = time.monotonic()
        self.last_ams_event_at = now
        track_value_changed = False
        track_key = ''
        track_value = None

        if entity == ENTITY_PLAYER:
            if attribute == PLAYER_ATTR_NAME and text:
                self.track['sourceApp'] = text
            elif attribute == PLAYER_ATTR_PLAYBACK_INFO:
                self.apply_playback_info(text)
        elif entity == ENTITY_TRACK:
            if attribute == TRACK_ATTR_ARTIST:
                track_key = 'artist'
                track_value = text
            elif attribute == TRACK_ATTR_ALBUM:
                track_key = 'album'
                track_value = text
            elif attribute == TRACK_ATTR_TITLE:
                track_key = 'title'
                track_value = text
            elif attribute == TRACK_ATTR_DURATION:
                try:
                    track_value = int(float(text or 0) * 1000)
                except ValueError:
                    track_value = 0
                track_key = 'durationMs'

            if track_key and self.track.get(track_key) != track_value:
                self.track[track_key] = track_value
                track_value_changed = True

        after_track_id = self.track_id()
        if entity == ENTITY_TRACK:
            self.track_attrs_seen.add(attribute)

        if entity == ENTITY_TRACK and track_value_changed:
            if not self.track_dirty:
                self.track_attrs_seen = {attribute}
            self.track_dirty = True
            self.track_last_changed_at = now
            self.track_metadata_settled = False
            self.completed_stale_started_at = 0.0

            if before_track_id != after_track_id:
                self.last_post_signature = ''
                self.playback_restart_pending_at = 0.0
                self.request_snapshot_if_due(force=not self.track_snapshot_requested)
                self.track_snapshot_requested = True
                if attribute in (
                    TRACK_ATTR_ARTIST,
                    TRACK_ATTR_TITLE,
                    TRACK_ATTR_DURATION
                ):
                    self.last_elapsed_ms = 0
                    self.last_elapsed_monotonic = now

            if self.track.get('title') or self.track.get('artist'):
                self.log(
                    'track snapshot: {} - {}'.format(
                        self.track.get('title') or 'Unknown title',
                        self.track.get('artist') or 'Unknown artist'
                    )
                )

        if entity == ENTITY_TRACK:
            settle_ms = (
                FAST_TRACK_SETTLE_MS
                if self.is_fast_publishable_track_snapshot()
                else TRACK_METADATA_SETTLE_MS
            )
            self.schedule_state_post(settle_ms)
        else:
            self.schedule_state_post(PLAYBACK_POST_DEBOUNCE_MS)

    def apply_playback_info(self, text):
        parts = [part.strip() for part in text.split(',')]
        now = time.monotonic()
        self.last_ams_event_at = now

        incoming_playing = None
        incoming_elapsed_ms = None
        if parts:
            incoming_playing = parts[0] in ('1', 'playing', 'Playing')
        if len(parts) >= 3:
            try:
                incoming_elapsed_ms = max(0, int(float(parts[2]) * 1000))
            except ValueError:
                incoming_elapsed_ms = None

        if (
            incoming_elapsed_ms is not None
            and incoming_elapsed_ms <= PLAYBACK_RESTART_PROGRESS_MS
            and self.display_track is not None
            and not self.track_dirty
            and self.estimated_progress_ms() >= PLAYBACK_RESTART_MIN_OLD_PROGRESS_MS
        ):
            self.track_dirty = True
            self.track_last_changed_at = now
            self.playback_restart_pending_at = now
            self.track_metadata_settled = False
            self.track_snapshot_requested = True
            self.last_post_signature = ''
            self.completed_stale_started_at = 0.0
            self.request_snapshot_if_due(force=True)
            self.log('playback restart detected; waiting for track metadata')

        if incoming_playing is not None:
            self.track['playing'] = incoming_playing
            if self.display_track is not None:
                self.display_track['playing'] = self.track['playing']

        if incoming_elapsed_ms is not None:
            self.last_elapsed_ms = incoming_elapsed_ms
            self.last_elapsed_monotonic = now
            self.completed_stale_started_at = 0.0

    def estimated_progress_ms(self):
        progress = self.last_elapsed_ms
        if self.track['playing']:
            progress += int((time.monotonic() - self.last_elapsed_monotonic) * 1000)

        duration = int(self.track.get('durationMs') or 0)
        if duration > 0:
            progress = min(progress, duration)
        return max(0, progress)

    def track_id(self, track=None):
        source = track or self.track
        return 'iphone_ams|{}|{}|{}|{}'.format(
            source.get('title', ''),
            source.get('artist', ''),
            source.get('album', ''),
            source.get('durationMs', 0)
        )

    def post_json(self, path, payload):
        body = json.dumps(payload).encode('utf-8')
        request = urllib.request.Request(
            BRIDGE_URL + path,
            data=body,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        with urllib.request.urlopen(request, timeout=3) as response:
            response.read()

    def post_connected(self, force=False, clear_player=False):
        now = time.monotonic()
        if not force and now - self.last_connected_post_at < 2:
            return

        now_ms = int(time.time() * 1000)
        self.update_sequence += 1
        payload = {
            'deviceId': self.device_path or 'iphone_ams',
            'deviceName': self.device_name or 'iPhone',
            'sourceName': self.track.get('sourceApp') or self.device_name or 'iPhone',
            'connected': True,
            'connectedOnly': True,
            'clearPlayer': bool(clear_player),
            'updateSequence': self.update_sequence,
            'player': {
                'sourceApp': self.track.get('sourceApp') or 'iPhone',
                'playing': bool(self.track.get('playing')),
                'paused': not bool(self.track.get('playing')),
                'stateTimestampMs': now_ms,
                'capturedAtMs': now_ms,
                'updateSequence': self.update_sequence
            }
        }

        try:
            self.post_json(POST_PATH, payload)
            self.last_connected_post_at = now
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            self.log('connected heartbeat failed: {}'.format(error))

    def flush_scheduled_state_post(self):
        self.pending_state_post_timer = 0
        self.post_state(force=True)
        return False

    def schedule_state_post(self, delay_ms=STATE_POST_DEBOUNCE_MS):
        if self.pending_state_post_timer:
            if int(delay_ms) >= TRACK_METADATA_SETTLE_MS or int(delay_ms) <= FAST_TRACK_SETTLE_MS:
                GLib.source_remove(self.pending_state_post_timer)
                self.pending_state_post_timer = 0
            else:
                return

        if self.pending_state_post_timer:
            return
        self.pending_state_post_timer = GLib.timeout_add(
            max(0, int(delay_ms)),
            self.flush_scheduled_state_post
        )

    def get_completed_track_stale_age_ms(self):
        duration = int(self.track.get('durationMs') or 0)
        if not self.track.get('playing') or duration <= 0:
            self.completed_stale_started_at = 0.0
            return 0

        progress = self.estimated_progress_ms()
        if progress < max(0, duration - 250):
            self.completed_stale_started_at = 0.0
            return 0

        now = time.monotonic()
        if not self.completed_stale_started_at:
            self.completed_stale_started_at = now
            return 0

        return int((now - self.completed_stale_started_at) * 1000)

    def has_metadata_snapshot(self):
        return bool(self.track.get('title') or self.track.get('artist'))

    def has_complete_track_snapshot(self):
        return bool(
            self.track.get('title', '').strip()
            and self.track.get('artist', '').strip()
            and int(self.track.get('durationMs') or 0) > 0
        )

    def has_text_track_snapshot(self, track=None):
        source = track or self.track
        return bool(
            source.get('title', '').strip()
            and source.get('artist', '').strip()
        )

    def is_transient_track_snapshot(self, track=None):
        source = track or self.track
        title = source.get('title', '').strip().lower()
        artist = source.get('artist', '').strip().lower()
        return bool(title == 'up next' and artist == 'dj x')

    def is_fast_publishable_track_snapshot(self):
        if not self.has_text_track_snapshot():
            return False

        if self.is_transient_track_snapshot():
            return True

        if self.display_track is None:
            return True

        title = self.track.get('title', '').strip()
        artist = self.track.get('artist', '').strip()
        display_title = self.display_track.get('title', '').strip()
        display_artist = self.display_track.get('artist', '').strip()
        title_changed = title != display_title
        artist_changed = artist != display_artist

        if title_changed:
            return True

        return bool(
            TRACK_ATTR_TITLE in self.track_attrs_seen
            and TRACK_ATTR_ARTIST in self.track_attrs_seen
            and artist_changed
        )

    def has_publishable_track_snapshot(self):
        return bool(
            self.has_complete_track_snapshot()
            or self.is_fast_publishable_track_snapshot()
            or (
                self.has_text_track_snapshot()
                and self.track_dirty_age_ms() >= TRACK_METADATA_SETTLE_MS
            )
        )

    def track_dirty_age_ms(self):
        if not self.track_dirty or not self.track_last_changed_at:
            return 0
        return int((time.monotonic() - self.track_last_changed_at) * 1000)

    def should_publish_current_track_snapshot(self):
        if not self.has_publishable_track_snapshot():
            return False

        if self.display_track is None:
            return not self.track_dirty or self.track_dirty_age_ms() >= TRACK_METADATA_SETTLE_MS

        if self.track_id(self.display_track) == self.track_id(self.track):
            return False

        return not self.track_dirty or self.track_dirty_age_ms() >= TRACK_METADATA_SETTLE_MS

    def promote_current_track_snapshot(self):
        self.display_track = dict(self.track)
        self.track_metadata_settled = True
        self.track_dirty = False
        self.track_snapshot_requested = False
        self.playback_restart_pending_at = 0.0
        self.track_attrs_seen = set()
        self.last_post_signature = ''

    def clear_expired_playback_restart_hold(self):
        if not self.track_dirty or not self.playback_restart_pending_at:
            return False
        if self.display_track is None:
            return False
        if self.track_id(self.display_track) != self.track_id(self.track):
            return False
        if self.track_dirty_age_ms() < PLAYBACK_RESTART_SUPPRESS_MS:
            return False

        self.track_dirty = False
        self.track_snapshot_requested = False
        self.playback_restart_pending_at = 0.0
        self.track_metadata_settled = True
        self.track_attrs_seen = set()
        self.last_post_signature = ''
        return True

    def should_reset_empty_ams_snapshot(self):
        if not self.ams_ready() or self.has_metadata_snapshot():
            return False

        if not self.last_ams_established_at:
            return False

        return time.monotonic() - self.last_ams_established_at >= 3.0

    def post_state(self, force=False):
        if self.should_publish_current_track_snapshot():
            self.promote_current_track_snapshot()

        display_track = self.display_track

        if self.track_dirty:
            if self.clear_expired_playback_restart_hold():
                display_track = self.display_track
            else:
                self.post_connected(force=force)
                return

        if display_track is None:
            self.post_connected(force=force)
            return

        title = display_track.get('title', '').strip()
        artist = display_track.get('artist', '').strip()
        if not title and not artist:
            self.post_connected(force=force)
            return

        transient = self.is_transient_track_snapshot(display_track)
        if not title or not artist:
            self.post_connected(force=force)
            return

        if int(display_track.get('durationMs') or 0) <= 0 and not transient:
            self.post_connected(force=force)
            return

        now_ms = int(time.time() * 1000)
        self.update_sequence += 1
        payload = {
            'deviceId': self.device_path or 'iphone_ams',
            'deviceName': self.device_name or 'iPhone',
            'sourceName': self.track.get('sourceApp') or 'iPhone',
            'updateSequence': self.update_sequence,
            'player': {
                'trackId': self.track_id(display_track),
                'trackTitle': title,
                'trackArtist': artist,
                'trackArtists': [artist] if artist else [],
                'trackAlbumTitle': display_track.get('album', ''),
                'durationMs': int(display_track.get('durationMs') or 0),
                'progressMs': self.estimated_progress_ms(),
                'playing': bool(self.track.get('playing')),
                'paused': not bool(self.track.get('playing')),
                'sourceApp': self.track.get('sourceApp') or 'iPhone',
                'transient': transient,
                'stateTimestampMs': now_ms,
                'capturedAtMs': now_ms,
                'updateSequence': self.update_sequence
            }
        }
        signature = json.dumps(payload['player'], sort_keys=True)
        if not force and signature == self.last_post_signature:
            return

        try:
            self.post_json(POST_PATH, payload)
            self.last_post_signature = signature
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            self.log('post failed: {}'.format(error))

    def post_disconnect(self):
        try:
            self.post_json('/api/iphone/disconnect', {})
        except (urllib.error.URLError, TimeoutError, OSError):
            pass

    def heartbeat(self):
        if self.connected:
            if not self.ams_ready():
                self.subscribe_ams()
            else:
                self.request_snapshot_if_due()

            if self.should_reset_empty_ams_snapshot():
                now = time.monotonic()
                if now - self.last_ams_reset_at >= AMS_RESET_COOLDOWN_MS / 1000.0:
                    self.last_ams_reset_at = now
                    self.reset_ams_subscription('AMS established without metadata')
                    self.subscribe_ams()
                return True

            stale_age_ms = self.get_completed_track_stale_age_ms()
            if stale_age_ms >= COMPLETED_TRACK_STALE_MS:
                now = time.monotonic()
                if now - self.last_ams_reset_at >= AMS_RESET_COOLDOWN_MS / 1000.0:
                    self.last_ams_reset_at = now
                    self.log(
                        'clearing completed stale AMS track after {}ms'.format(
                            stale_age_ms
                        )
                    )
                    self.post_connected(force=True, clear_player=True)
                    self.reset_track_metadata()
                    self.reset_ams_subscription('completed track stopped updating')
                    self.subscribe_ams()
                return True

            self.post_state(force=False)
        return True

    def reconnect_tick(self):
        if self.wifi_setup_active():
            if self.connected:
                self.disconnect_current_device('Wi-Fi setup is active')
            self.set_adapter_provisioning_mode()
            return True

        owner = self.current_owner()

        if owner == 'android':
            if self.connected:
                self.disconnect_current_device('Android owns Screenify')
            self.set_adapter_locked_mode()
            return True

        if owner == 'iphone_ams':
            self.set_adapter_connected_mode()
            return True

        if not self.connected:
            if self.has_connected_apple_device():
                self.set_adapter_connected_mode()
            else:
                self.set_adapter_idle_mode()
            self.scan_once()
        return True

    def stop(self, *_args):
        self.log('stopping')
        try:
            self.post_disconnect()
        finally:
            self.loop.quit()

    def run(self):
        self.load_last_device()
        if self.wifi_setup_active():
            self.set_adapter_provisioning_mode()
        else:
            self.set_adapter_idle_mode()
        signal.signal(signal.SIGINT, self.stop)
        signal.signal(signal.SIGTERM, self.stop)
        GLib.timeout_add(CONNECT_RETRY_MS, self.reconnect_tick)
        GLib.timeout_add(HEARTBEAT_MS, self.heartbeat)
        self.scan_once()
        self.loop.run()


if __name__ == '__main__':
    bridge = ScreenifyAmsBridge()
    bridge.run()
