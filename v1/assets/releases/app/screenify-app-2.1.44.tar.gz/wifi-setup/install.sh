#!/usr/bin/env bash
set -euo pipefail

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo 'Run this installer as root.' >&2
  exit 1
fi

source_dir=${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}
for required in \
  screenify_wifi_setup.py \
  screenify_wifi_ble.py \
  screenify-wifi-setup.service \
  wifi-setup.env \
  web/index.html \
  web/setup.css \
  web/setup.js; do
  if [[ ! -f "$source_dir/$required" ]]; then
    echo "Missing setup asset: $source_dir/$required" >&2
    exit 1
  fi
done

missing_packages=()
command -v nmcli >/dev/null 2>&1 || missing_packages+=(network-manager)
command -v hostapd >/dev/null 2>&1 || missing_packages+=(hostapd)
command -v dnsmasq >/dev/null 2>&1 || missing_packages+=(dnsmasq)
command -v curl >/dev/null 2>&1 || missing_packages+=(curl)
python3 -c 'import cryptography' >/dev/null 2>&1 || missing_packages+=(python3-cryptography)

if ! command -v create_ap >/dev/null 2>&1; then
  echo 'Missing required Orange Pi create_ap utility at /usr/bin/create_ap.' >&2
  exit 1
fi

if (( ${#missing_packages[@]} )); then
  if [[ ${SCREENIFY_WIFI_SETUP_INSTALL_PACKAGES:-1} != 1 ]]; then
    printf 'Missing required packages: %s\n' "${missing_packages[*]}" >&2
    exit 1
  fi
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${missing_packages[@]}"
fi

install -d -o root -g root -m 0755 \
  /opt/screenify/wifi-setup/web \
  /etc/screenify

install -o root -g root -m 0755 \
  "$source_dir/screenify_wifi_setup.py" \
  "$source_dir/screenify_wifi_ble.py" \
  /opt/screenify/wifi-setup/
install -o root -g root -m 0644 \
  "$source_dir/web/index.html" \
  "$source_dir/web/setup.css" \
  "$source_dir/web/setup.js" \
  /opt/screenify/wifi-setup/web/
install -o root -g root -m 0644 \
  "$source_dir/screenify-wifi-setup.service" \
  /etc/systemd/system/screenify-wifi-setup.service
install -o root -g root -m 0600 \
  "$source_dir/wifi-setup.env" \
  /etc/screenify/wifi-setup.env

python3 -m py_compile /opt/screenify/wifi-setup/screenify_wifi_setup.py
systemctl daemon-reload
rm -f /etc/NetworkManager/dnsmasq-shared.d/90-screenify-captive.conf
nmcli connection delete id screenify-setup >/dev/null 2>&1 || true
systemctl enable screenify-wifi-setup.service
systemctl restart screenify-wifi-setup.service

echo 'SCREENIFY_WIFI_SETUP_INSTALLED'
