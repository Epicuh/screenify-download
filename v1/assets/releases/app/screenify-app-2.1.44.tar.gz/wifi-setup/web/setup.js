(function () {
  'use strict'

  const isDisplay = window.location.pathname === '/display'
  document.body.classList.add(isDisplay ? 'is-display' : 'is-portal')

  const byId = (id) => document.getElementById(id)
  const displayDevice = byId('display-device')
  const displayCode = byId('display-code')
  const displayHotspotName = byId('display-hotspot-name')
  const displayHotspotPassword = byId('display-hotspot-password')
  const iphoneCard = document.querySelector('.iphone-card')
  const displayStatus = byId('display-status-text')
  const form = byId('wifi-form')
  const networkList = byId('network-list')
  const manualToggle = byId('manual-toggle')
  const manualFields = byId('manual-fields')
  const manualSsid = byId('manual-ssid')
  const hiddenNetwork = byId('hidden-network')
  const passwordFields = byId('password-fields')
  const passwordInput = byId('wifi-password')
  const passwordToggle = byId('password-toggle')
  const connectButton = byId('connect-button')
  const portalError = byId('portal-error')
  const portalStatus = byId('portal-status')
  const progressPanel = byId('progress-panel')
  const progressTitle = byId('progress-title')
  const progressDetail = byId('progress-detail')

  let redirected = false
  let latestStatus = null
  let selectedNetwork = null
  let manualMode = false
  let submitting = false
  let networkFingerprint = ''

  function renderDisplay(status) {
    if (status.mode === 'online' && !redirected) {
      redirected = true
      window.location.replace(
        'http://127.0.0.1:8080/screenify-kiosk.html?connected=' + Date.now()
      )
      return
    }

    const setup = status.setup || {}
    const hotspot = setup.hotspot || {}
    displayDevice.textContent = setup.deviceName || status.deviceName || 'Screenify'
    displayCode.textContent = setup.code || '----------'
    const hotspotStarting = String(status.phase || '').toLowerCase().includes('starting iphone')
    const iphoneAvailable = Boolean(hotspot.active || hotspotStarting)
    iphoneCard.classList.toggle('method-unavailable', !iphoneAvailable)
    displayHotspotName.textContent = hotspot.active
      ? (hotspot.ssid || 'Screenify Setup')
      : (hotspotStarting ? 'Starting…' : 'Available when offline')
    displayHotspotPassword.textContent = hotspot.active
      ? (hotspot.password || '••••••••')
      : (hotspotStarting ? 'PLEASE WAIT' : 'BLUETOOTH ONLY')
    displayStatus.textContent =
      status.error ||
      status.phase ||
      status.detail ||
      'Waiting for your phone'
  }

  function signalLabel(signal) {
    if (signal >= 75) return 'Strong signal'
    if (signal >= 45) return 'Good signal'
    return 'Weak signal'
  }

  function renderNetworks(networks) {
    const fingerprint = JSON.stringify(networks)
    if (fingerprint === networkFingerprint) return
    networkFingerprint = fingerprint
    networkList.replaceChildren()

    if (!networks.length) {
      const empty = document.createElement('div')
      empty.className = 'network-empty'
      empty.textContent = 'No networks found. Enter yours below.'
      networkList.appendChild(empty)
      setManualMode(true)
      return
    }

    networks.forEach((network) => {
      const button = document.createElement('button')
      button.type = 'button'
      button.className = 'network-option'
      button.dataset.ssid = network.ssid
      button.setAttribute('aria-label', network.ssid + ', ' + signalLabel(network.signal))

      const icon = document.createElement('span')
      icon.className = 'wifi-icon'
      icon.setAttribute('aria-hidden', 'true')
      icon.appendChild(document.createElement('i'))

      const name = document.createElement('span')
      name.className = 'network-name'
      name.textContent = network.ssid

      const security = document.createElement('span')
      security.className = 'network-security'
      security.textContent = String(network.security || '').toUpperCase() === 'OPEN'
        ? 'Open'
        : signalLabel(Number(network.signal) || 0)

      button.append(icon, name, security)
      button.addEventListener('click', () => selectNetwork(network, button))
      networkList.appendChild(button)
    })
  }

  function selectNetwork(network, button) {
    selectedNetwork = network
    manualMode = false
    manualFields.hidden = true
    manualToggle.setAttribute('aria-expanded', 'false')
    manualToggle.textContent = 'My network isn’t listed'
    networkList.querySelectorAll('.network-option').forEach((option) => {
      option.classList.toggle('selected', option === button)
    })
    const isOpen = String(network.security || '').toUpperCase() === 'OPEN'
    passwordFields.hidden = isOpen
    if (isOpen) passwordInput.value = ''
    updateConnectButton()
  }

  function setManualMode(enabled) {
    manualMode = enabled
    if (enabled) selectedNetwork = null
    manualFields.hidden = !enabled
    manualToggle.setAttribute('aria-expanded', String(enabled))
    manualToggle.textContent = enabled ? 'Choose from available networks' : 'My network isn’t listed'
    passwordFields.hidden = false
    networkList.querySelectorAll('.network-option').forEach((option) => {
      option.classList.remove('selected')
    })
    if (enabled) window.setTimeout(() => manualSsid.focus(), 0)
    updateConnectButton()
  }

  function updateConnectButton() {
    if (!connectButton) return
    const ssid = manualMode ? manualSsid.value.trim() : (selectedNetwork && selectedNetwork.ssid)
    const security = manualMode ? 'WPA2' : String((selectedNetwork && selectedNetwork.security) || 'WPA2')
    const open = security.toUpperCase() === 'OPEN'
    const passwordOkay = open || passwordInput.value.length >= 8
    connectButton.disabled = submitting || !ssid || !passwordOkay
  }

  function showPortalError(message) {
    portalError.textContent = message
    portalError.hidden = !message
  }

  function renderPortal(status) {
    latestStatus = status
    const setup = status.setup || {}
    const networks = Array.isArray(status.networks) ? status.networks : []

    if (!submitting) renderNetworks(networks)
    if (status.error && !submitting) showPortalError(status.error)

    if (status.mode === 'online') {
      form.hidden = true
      progressPanel.hidden = false
      progressTitle.textContent = 'Screenify is connected'
      progressDetail.textContent = 'You can close this page and return to your normal Wi-Fi.'
      portalStatus.textContent = status.connectedSsid
        ? 'Connected to ' + status.connectedSsid
        : 'Wi-Fi setup complete'
      return
    }

    if (submitting) {
      form.hidden = true
      progressPanel.hidden = false
      progressTitle.textContent = 'Screenify is switching networks'
      progressDetail.textContent =
        'This page will stop updating when the setup network closes. Watch the physical Screenify display for the result.'
      return
    }

    form.hidden = false
    progressPanel.hidden = true
    portalStatus.textContent = setup.hotspot && setup.hotspot.active
      ? 'Connected securely to ' + setup.hotspot.ssid
      : (status.phase || 'Preparing setup')
    updateConnectButton()
  }

  async function refresh() {
    try {
      const response = await fetch('/api/status', { cache: 'no-store' })
      if (!response.ok) throw new Error('Status unavailable')
      const status = await response.json()
      if (isDisplay) renderDisplay(status)
      else renderPortal(status)
    } catch (_error) {
      if (isDisplay) {
        displayStatus.textContent = 'Restarting Wi-Fi setup…'
      } else if (!submitting) {
        portalStatus.textContent = 'Reconnecting to Screenify…'
      }
    }
  }

  if (manualToggle) {
    manualToggle.addEventListener('click', () => setManualMode(!manualMode))
    manualSsid.addEventListener('input', updateConnectButton)
    passwordInput.addEventListener('input', updateConnectButton)
    passwordToggle.addEventListener('click', () => {
      const show = passwordInput.type === 'password'
      passwordInput.type = show ? 'text' : 'password'
      passwordToggle.textContent = show ? 'Hide' : 'Show'
      passwordToggle.setAttribute('aria-label', show ? 'Hide password' : 'Show password')
    })

    form.addEventListener('submit', async (event) => {
      event.preventDefault()
      if (!latestStatus || submitting) return
      const setup = latestStatus.setup || {}
      const ssid = manualMode ? manualSsid.value.trim() : selectedNetwork && selectedNetwork.ssid
      const security = manualMode
        ? 'WPA2'
        : String((selectedNetwork && selectedNetwork.security) || 'WPA2')
      const open = security.toUpperCase() === 'OPEN'
      if (!ssid) return

      submitting = true
      showPortalError('')
      updateConnectButton()
      form.hidden = true
      progressPanel.hidden = false
      progressTitle.textContent = 'Sending Wi-Fi details'
      progressDetail.textContent = 'Keep this page open until Screenify begins testing.'

      try {
        const response = await fetch('/api/connect', {
          method: 'POST',
          cache: 'no-store',
          headers: {
            'Content-Type': 'application/json',
            'X-Screenify-Token': setup.token || ''
          },
          body: JSON.stringify({
            ssid: ssid,
            password: open ? '' : passwordInput.value,
            security: security,
            hidden: manualMode && hiddenNetwork.checked
          })
        })
        const payload = await response.json()
        if (!response.ok) throw new Error(payload.error || 'Wi-Fi setup could not start.')
        progressTitle.textContent = 'Testing your Wi-Fi'
        progressDetail.textContent =
          'This setup network will disconnect now. Watch the Screenify display for success or an error.'
      } catch (error) {
        submitting = false
        form.hidden = false
        progressPanel.hidden = true
        showPortalError(error.message || 'Wi-Fi setup could not start.')
        updateConnectButton()
      }
    })
  }

  refresh()
  window.setInterval(refresh, isDisplay ? 900 : 1400)
})()
