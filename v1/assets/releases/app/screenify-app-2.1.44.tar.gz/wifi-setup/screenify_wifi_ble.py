#!/usr/bin/env python3
"""BlueZ GATT transport for Screenify Wi-Fi provisioning.

The Orange Pi Zero 2 W's in-tree Unisoc driver can join Wi-Fi networks but its
access-point transmit path is unusable. This module keeps that radio in station
mode and carries setup data over an encrypted Bluetooth LE connection instead.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import secrets
import threading
from typing import Any, Callable, Optional

import dbus
import dbus.exceptions
import dbus.mainloop.glib
import dbus.service
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from gi.repository import GLib


LOG = logging.getLogger("screenify-wifi-setup.ble")

BLUEZ_SERVICE = "org.bluez"
DBUS_OBJECT_MANAGER = "org.freedesktop.DBus.ObjectManager"
DBUS_PROPERTIES = "org.freedesktop.DBus.Properties"
GATT_MANAGER = "org.bluez.GattManager1"
GATT_SERVICE = "org.bluez.GattService1"
GATT_CHARACTERISTIC = "org.bluez.GattCharacteristic1"
ADVERTISEMENT_MANAGER = "org.bluez.LEAdvertisingManager1"
ADVERTISEMENT = "org.bluez.LEAdvertisement1"
ADAPTER = "org.bluez.Adapter1"

SERVICE_UUID = "c7a30001-89f4-4c2f-a3d9-1d673ef10b50"
INFO_UUID = "c7a30002-89f4-4c2f-a3d9-1d673ef10b50"
NETWORKS_UUID = "c7a30003-89f4-4c2f-a3d9-1d673ef10b50"
COMMAND_UUID = "c7a30004-89f4-4c2f-a3d9-1d673ef10b50"
STATUS_UUID = "c7a30005-89f4-4c2f-a3d9-1d673ef10b50"

ROOT_PATH = "/com/screenify/wifi"
SERVICE_PATH = ROOT_PATH + "/service0"
ADVERTISEMENT_PATH = ROOT_PATH + "/advertisement0"
MAX_COMMAND_BYTES = 2048
PROTOCOL_VERSION = 3
KDF_ITERATIONS = 120_000
KDF_SALT_BYTES = 16
AES_NONCE_BYTES = 12
COMMAND_AAD = b"screenify-wifi-setup-v3"


def _byte_array(payload: bytes) -> dbus.Array:
    return dbus.Array([dbus.Byte(value) for value in payload], signature="y")


def _json_bytes(payload: dict[str, Any]) -> bytes:
    return json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")


class InvalidArgs(dbus.exceptions.DBusException):
    _dbus_error_name = "org.freedesktop.DBus.Error.InvalidArgs"


class Failed(dbus.exceptions.DBusException):
    _dbus_error_name = "org.bluez.Error.Failed"


class NotSupported(dbus.exceptions.DBusException):
    _dbus_error_name = "org.bluez.Error.NotSupported"


class Application(dbus.service.Object):
    def __init__(self, bus: dbus.Bus, owner: "BluetoothProvisioningServer"):
        super().__init__(bus, ROOT_PATH)
        self.service = Service(bus, owner)

    @dbus.service.method(DBUS_OBJECT_MANAGER, out_signature="a{oa{sa{sv}}}")
    def GetManagedObjects(self) -> dict[dbus.ObjectPath, Any]:  # noqa: N802
        objects: dict[dbus.ObjectPath, Any] = {
            dbus.ObjectPath(self.service.path): self.service.properties()
        }
        for characteristic in self.service.characteristics:
            objects[dbus.ObjectPath(characteristic.path)] = characteristic.properties()
        return objects


class Service(dbus.service.Object):
    def __init__(self, bus: dbus.Bus, owner: "BluetoothProvisioningServer"):
        self.path = SERVICE_PATH
        super().__init__(bus, self.path)
        self.characteristics = [
            ReadCharacteristic(
                bus,
                self,
                0,
                INFO_UUID,
                owner.info_payload,
            ),
            ReadCharacteristic(
                bus,
                self,
                1,
                NETWORKS_UUID,
                owner.networks_payload,
            ),
            CommandCharacteristic(bus, self, 2, owner),
            StatusCharacteristic(bus, self, 3, owner),
        ]

    def properties(self) -> dict[str, dict[str, Any]]:
        return {
            GATT_SERVICE: {
                "UUID": SERVICE_UUID,
                "Primary": dbus.Boolean(True),
                "Characteristics": dbus.Array(
                    [
                        dbus.ObjectPath(characteristic.path)
                        for characteristic in self.characteristics
                    ],
                    signature="o",
                ),
            }
        }

    @dbus.service.method(
        DBUS_PROPERTIES,
        in_signature="s",
        out_signature="a{sv}",
    )
    def GetAll(self, interface: str) -> dict[str, Any]:  # noqa: N802
        if interface != GATT_SERVICE:
            raise InvalidArgs()
        return self.properties()[GATT_SERVICE]


class Characteristic(dbus.service.Object):
    def __init__(
        self,
        bus: dbus.Bus,
        service: Service,
        index: int,
        uuid: str,
        flags: list[str],
    ):
        self.path = f"{service.path}/char{index}"
        self.service = service
        self.uuid = uuid
        self.flags = flags
        super().__init__(bus, self.path)

    def properties(self) -> dict[str, dict[str, Any]]:
        return {
            GATT_CHARACTERISTIC: {
                "Service": dbus.ObjectPath(self.service.path),
                "UUID": self.uuid,
                "Flags": dbus.Array(self.flags, signature="s"),
                "Descriptors": dbus.Array([], signature="o"),
            }
        }

    @dbus.service.method(
        DBUS_PROPERTIES,
        in_signature="s",
        out_signature="a{sv}",
    )
    def GetAll(self, interface: str) -> dict[str, Any]:  # noqa: N802
        if interface != GATT_CHARACTERISTIC:
            raise InvalidArgs()
        return self.properties()[GATT_CHARACTERISTIC]

    @dbus.service.signal(
        DBUS_PROPERTIES,
        signature="sa{sv}as",
    )
    def PropertiesChanged(  # noqa: N802
        self,
        interface: str,
        changed: dict[str, Any],
        invalidated: list[str],
    ) -> None:
        pass


class ReadCharacteristic(Characteristic):
    def __init__(
        self,
        bus: dbus.Bus,
        service: Service,
        index: int,
        uuid: str,
        payload: Callable[[], bytes],
    ):
        super().__init__(bus, service, index, uuid, ["read"])
        self.payload = payload

    @dbus.service.method(
        GATT_CHARACTERISTIC,
        in_signature="a{sv}",
        out_signature="ay",
    )
    def ReadValue(self, options: dict[str, Any]) -> dbus.Array:  # noqa: N802
        offset = int(options.get("offset", 0))
        value = self.payload()
        if offset < 0 or offset > len(value):
            raise InvalidArgs()
        return _byte_array(value[offset:])


class CommandCharacteristic(Characteristic):
    def __init__(
        self,
        bus: dbus.Bus,
        service: Service,
        index: int,
        owner: "BluetoothProvisioningServer",
    ):
        super().__init__(bus, service, index, COMMAND_UUID, ["write"])
        self.owner = owner

    @dbus.service.method(
        GATT_CHARACTERISTIC,
        in_signature="aya{sv}",
    )
    def WriteValue(  # noqa: N802
        self,
        value: dbus.Array,
        options: dict[str, Any],
    ) -> None:
        del options
        raw = bytes(value)
        if not raw or len(raw) > MAX_COMMAND_BYTES:
            self.owner.protocol_error = "The setup request was empty or too large."
            raise Failed(self.owner.protocol_error)
        try:
            payload = self.owner.decode_command(raw)
            job_id = self.owner.app.request_bluetooth_connection(payload)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            self.owner.protocol_error = str(error) or "The setup request was invalid."
            raise Failed(self.owner.protocol_error) from error
        except (PermissionError, RuntimeError) as error:
            self.owner.protocol_error = str(error)
            raise Failed(self.owner.protocol_error) from error
        self.owner.protocol_error = ""
        self.owner.last_job_id = job_id
        self.owner.emit_status(force=True)


class StatusCharacteristic(Characteristic):
    def __init__(
        self,
        bus: dbus.Bus,
        service: Service,
        index: int,
        owner: "BluetoothProvisioningServer",
    ):
        super().__init__(bus, service, index, STATUS_UUID, ["read", "notify"])
        self.owner = owner
        self.notifying = False

    @dbus.service.method(
        GATT_CHARACTERISTIC,
        in_signature="a{sv}",
        out_signature="ay",
    )
    def ReadValue(self, options: dict[str, Any]) -> dbus.Array:  # noqa: N802
        offset = int(options.get("offset", 0))
        value = self.owner.status_payload()
        if offset < 0 or offset > len(value):
            raise InvalidArgs()
        return _byte_array(value[offset:])

    @dbus.service.method(GATT_CHARACTERISTIC)
    def StartNotify(self) -> None:  # noqa: N802
        if self.notifying:
            return
        self.notifying = True
        self.owner.emit_status(force=True)

    @dbus.service.method(GATT_CHARACTERISTIC)
    def StopNotify(self) -> None:  # noqa: N802
        self.notifying = False

    def notify(self, value: bytes) -> None:
        if not self.notifying:
            return
        self.PropertiesChanged(
            GATT_CHARACTERISTIC,
            {"Value": _byte_array(value)},
            [],
        )


class Advertisement(dbus.service.Object):
    def __init__(self, bus: dbus.Bus, local_name: str):
        self.path = ADVERTISEMENT_PATH
        self.local_name = local_name[:26]
        super().__init__(bus, self.path)

    def properties(self) -> dict[str, Any]:
        return {
            "Type": "peripheral",
            "ServiceUUIDs": dbus.Array([SERVICE_UUID], signature="s"),
            "LocalName": self.local_name,
            "Discoverable": dbus.Boolean(False),
        }

    @dbus.service.method(
        DBUS_PROPERTIES,
        in_signature="s",
        out_signature="a{sv}",
    )
    def GetAll(self, interface: str) -> dict[str, Any]:  # noqa: N802
        if interface != ADVERTISEMENT:
            raise InvalidArgs()
        return self.properties()

    @dbus.service.method(ADVERTISEMENT)
    def Release(self) -> None:  # noqa: N802
        LOG.info("Bluetooth setup advertisement released")


class BluetoothProvisioningServer:
    """Owns the BlueZ objects and synchronizes advertising with setup mode."""

    def __init__(self, app: Any):
        self.app = app
        self.protocol_error = ""
        self.last_job_id = ""
        self.session_salt = secrets.token_bytes(KDF_SALT_BYTES)
        self.bus: Optional[dbus.Bus] = None
        self.loop: Optional[GLib.MainLoop] = None
        self.application: Optional[Application] = None
        self.advertisement: Optional[Advertisement] = None
        self.gatt_manager: Any = None
        self.advertisement_manager: Any = None
        self.adapter_properties: Any = None
        self.adapter_interface: Any = None
        self.advertising = False
        self.advertising_pending = False
        self.last_status = b""
        self.thread: Optional[threading.Thread] = None
        self.ready = threading.Event()
        self.stopped = threading.Event()
        self.start_error: Optional[BaseException] = None

    def info_payload(self) -> bytes:
        return _json_bytes(
            {
                "version": PROTOCOL_VERSION,
                "device": self.app.config.setup_ssid,
                "codeRequired": True,
                "codeLength": len(self.app.bluetooth_setup_code()),
                "secure": True,
                "salt": base64.b64encode(self.session_salt).decode("ascii"),
                "iterations": KDF_ITERATIONS,
            }
        )

    def decode_command(self, raw: bytes) -> dict[str, Any]:
        try:
            envelope = json.loads(raw.decode("utf-8"))
            if not isinstance(envelope, dict):
                raise ValueError("The encrypted setup request is invalid.")
            if int(envelope.get("v", 0)) != PROTOCOL_VERSION:
                raise ValueError("Update the Screenify app and try again.")
            nonce = base64.b64decode(
                str(envelope.get("nonce", "")),
                validate=True,
            )
            ciphertext = base64.b64decode(
                str(envelope.get("data", "")),
                validate=True,
            )
            if len(nonce) != AES_NONCE_BYTES or not ciphertext:
                raise ValueError("The encrypted setup request is invalid.")
        except (
            UnicodeDecodeError,
            json.JSONDecodeError,
            ValueError,
            TypeError,
        ) as error:
            raise ValueError("The encrypted setup request is invalid.") from error

        code = self.app.bluetooth_setup_code()
        key = hashlib.pbkdf2_hmac(
            "sha256",
            code.encode("utf-8"),
            self.session_salt,
            KDF_ITERATIONS,
            dklen=32,
        )
        try:
            plaintext = AESGCM(key).decrypt(nonce, ciphertext, COMMAND_AAD)
        except InvalidTag as error:
            raise PermissionError(
                "The setup code does not match the Screenify display."
            ) from error
        try:
            payload = json.loads(plaintext.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError("The encrypted setup request is invalid.") from error
        if not isinstance(payload, dict):
            raise ValueError("The encrypted setup request is invalid.")
        return payload

    def networks_payload(self) -> bytes:
        status = self.app.bluetooth_status()
        return _json_bytes(
            {
                "networks": [
                    {
                        "s": item["ssid"],
                        "g": item["signal"],
                        "k": item["security"],
                    }
                    for item in status["networks"]
                ]
            }
        )

    def status_payload(self) -> bytes:
        status = self.app.bluetooth_status()
        return _json_bytes(
            {
                "mode": status["mode"],
                "phase": status["phase"],
                "detail": status["detail"],
                "error": self.protocol_error or status["error"],
                "jobId": self.last_job_id,
                "ip": status["ip"],
            }
        )

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(
            target=self._run,
            name="screenify-wifi-ble",
            daemon=True,
        )
        self.thread.start()
        if not self.ready.wait(timeout=10):
            raise RuntimeError("Timed out while starting Bluetooth Wi-Fi setup.")
        if self.start_error is not None:
            raise RuntimeError(
                f"Bluetooth Wi-Fi setup failed: {self.start_error}"
            ) from self.start_error

    def stop(self) -> None:
        self.stopped.set()
        if self.loop is not None:
            GLib.idle_add(self.loop.quit)
        if self.thread is not None:
            self.thread.join(timeout=5)

    def _find_adapter(self, bus: dbus.Bus) -> str:
        manager = dbus.Interface(
            bus.get_object(BLUEZ_SERVICE, "/"),
            DBUS_OBJECT_MANAGER,
        )
        for path, interfaces in manager.GetManagedObjects().items():
            if GATT_MANAGER in interfaces and ADVERTISEMENT_MANAGER in interfaces:
                return str(path)
        raise RuntimeError("No Bluetooth LE peripheral adapter is available.")

    def _run(self) -> None:
        try:
            dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
            self.bus = dbus.SystemBus()
            adapter_path = self._find_adapter(self.bus)
            adapter = self.bus.get_object(BLUEZ_SERVICE, adapter_path)
            self.gatt_manager = dbus.Interface(adapter, GATT_MANAGER)
            self.advertisement_manager = dbus.Interface(
                adapter,
                ADVERTISEMENT_MANAGER,
            )
            self.adapter_properties = dbus.Interface(adapter, DBUS_PROPERTIES)
            self.adapter_interface = dbus.Interface(adapter, ADAPTER)
            self.application = Application(self.bus, self)
            self.advertisement = Advertisement(
                self.bus,
                self.app.config.setup_ssid,
            )
            self.loop = GLib.MainLoop()
            self.gatt_manager.RegisterApplication(
                ROOT_PATH,
                {},
                reply_handler=self._application_registered,
                error_handler=self._application_registration_failed,
            )
            GLib.timeout_add(500, self._tick)
            self.loop.run()
        except BaseException as error:
            self.start_error = error
            LOG.exception("Bluetooth provisioning thread failed")
            self.ready.set()
        finally:
            # BlueZ removes the application and advertisement when this
            # process's private D-Bus connection closes.
            pass

    def _application_registered(self) -> None:
        LOG.info("Bluetooth Wi-Fi setup GATT service registered")
        self.ready.set()

    def _application_registration_failed(
        self,
        error: dbus.exceptions.DBusException,
    ) -> None:
        self.start_error = error
        LOG.error("Bluetooth GATT registration failed: %s", error)
        self.ready.set()
        if self.loop is not None:
            self.loop.quit()

    def _tick(self) -> bool:
        if self.stopped.is_set():
            if self.loop is not None:
                self.loop.quit()
            return False
        should_advertise = self.app.state.get("mode") == "setup"
        if should_advertise and self.adapter_properties is not None:
            # The iPhone metadata bridge shares this controller. Reassert the
            # provisioning posture so it cannot reopen OS pairing or discovery
            # while Android is using the unpaired GATT service.
            try:
                if self.adapter_interface is not None:
                    try:
                        self.adapter_interface.StopDiscovery()
                    except dbus.exceptions.DBusException:
                        pass
                self.adapter_properties.Set(
                    ADAPTER,
                    "Powered",
                    dbus.Boolean(True),
                )
                self.adapter_properties.Set(
                    ADAPTER,
                    "Pairable",
                    dbus.Boolean(False),
                )
                self.adapter_properties.Set(
                    ADAPTER,
                    "Discoverable",
                    dbus.Boolean(False),
                )
            except dbus.exceptions.DBusException as error:
                LOG.debug("Could not refresh Bluetooth setup posture: %s", error)
        if should_advertise and not self.advertising and not self.advertising_pending:
            self._register_advertisement()
        elif not should_advertise and (self.advertising or self.advertising_pending):
            self._unregister_advertisement()
        self.emit_status()
        return True

    def _register_advertisement(self) -> None:
        if self.advertisement_manager is None or self.advertisement is None:
            return
        try:
            if self.adapter_interface is not None:
                try:
                    self.adapter_interface.StopDiscovery()
                except dbus.exceptions.DBusException:
                    pass
            self.adapter_properties.Set(
                ADAPTER,
                "Powered",
                dbus.Boolean(True),
            )
            self.adapter_properties.Set(
                ADAPTER,
                "Pairable",
                dbus.Boolean(False),
            )
            self.adapter_properties.Set(
                ADAPTER,
                "Discoverable",
                dbus.Boolean(False),
            )
            self.advertising_pending = True
            self.advertisement_manager.RegisterAdvertisement(
                ADVERTISEMENT_PATH,
                {},
                reply_handler=self._advertisement_registered,
                error_handler=self._advertisement_registration_failed,
            )
        except dbus.exceptions.DBusException as error:
            self.advertising_pending = False
            self.protocol_error = f"Bluetooth advertising failed: {error}"
            LOG.error("%s", self.protocol_error)

    def _advertisement_registered(self) -> None:
        self.advertising_pending = False
        self.advertising = True
        self.protocol_error = ""
        LOG.info(
            "Advertising Bluetooth Wi-Fi setup as %s",
            self.app.config.setup_ssid,
        )

    def _advertisement_registration_failed(
        self,
        error: dbus.exceptions.DBusException,
    ) -> None:
        self.advertising_pending = False
        self.advertising = False
        self.protocol_error = f"Bluetooth advertising failed: {error}"
        LOG.error("%s", self.protocol_error)

    def _unregister_advertisement(self) -> None:
        if (
            (not self.advertising and not self.advertising_pending)
            or self.advertisement_manager is None
            or self.advertisement is None
        ):
            return
        self.advertising = False
        self.advertising_pending = False
        try:
            self.advertisement_manager.UnregisterAdvertisement(
                ADVERTISEMENT_PATH,
                reply_handler=lambda: None,
                error_handler=lambda error: LOG.debug(
                    "Bluetooth advertisement already stopped: %s",
                    error,
                ),
            )
        except dbus.exceptions.DBusException:
            pass
        LOG.info("Bluetooth Wi-Fi setup advertisement stopped")

    def emit_status(self, force: bool = False) -> None:
        if self.application is None:
            return
        value = self.status_payload()
        if not force and value == self.last_status:
            return
        self.last_status = value
        for characteristic in self.application.service.characteristics:
            if isinstance(characteristic, StatusCharacteristic):
                characteristic.notify(value)
                return
