# Controlled provisioning test

## Connected-state safety check

1. Confirm the Orange Pi is connected and record its active profile UUID.
2. Trigger **Change Wi-Fi** from the Android app.
3. Confirm the display shows both setup instructions but `wlan0` remains
   connected and no `Screenify ####` hotspot is advertised.
4. Complete one Android Bluetooth setup attempt and confirm the current profile
   is retained if the candidate fails.

## First-run iPhone test

1. Temporarily disable autoconnect on the recorded customer profile. Do not
   delete the profile.
2. Disconnect `wlan0` and wait for the setup display.
3. Confirm the displayed `Screenify ####` network is visible on iPhone.
4. Join it with the displayed setup password.
5. Confirm the captive page opens. If it does not, open
   `http://screenify.setup`.
6. Choose the currently available home Wi-Fi, enter its password, and submit.
7. Confirm the iPhone is disconnected from the temporary hotspot while the
   physical display shows testing progress.
8. Confirm the display returns to normal, the Orange Pi has internet access,
   and the saved customer profile remains present.
9. Repeat with a deliberately wrong password. The same setup hotspot must
   return, the portal must show the error, and another attempt must be possible.

## Android first-run regression check

While the Orange Pi is offline and advertising the setup hotspot, use the
Android app’s Bluetooth flow. Confirm its encrypted request wins the same
single candidate lock, the hotspot closes for testing, and normal Android
connection resumes after success.

For a dry run that validates the request without activating a candidate, set
`SCREENIFY_WIFI_HOLD_EXISTING=1` temporarily and restart the setup service.
