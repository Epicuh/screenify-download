# Screenify Wi-Fi setup

Screenify supports two local setup methods:

- Android uses encrypted Bluetooth Low Energy provisioning.
- When Screenify is offline, iPhone can join the temporary WPA2
  `Screenify ####` network and use its captive setup page without an app.

The Orange Pi Zero 2W radio cannot be a client and access point at the same
time. Screenify therefore starts the iPhone setup network only when `wlan0` is
offline. Opening **Change Wi-Fi** while Screenify is already online remains
Bluetooth-only and does not interrupt the current connection.

## Behavior

- With no usable Wi-Fi, the setup display opens after a 30-second grace period.
- The display shows the iPhone hotspot name/password and the Android Bluetooth
  setup code.
- The iPhone setup page opens automatically after joining the hotspot. If
  captive detection does not open it, `http://screenify.setup` reaches the same
  local page.
- The home network list is scanned before the radio switches into hotspot mode.
- After credentials are submitted, the setup hotspot closes and NetworkManager
  tests a temporary candidate profile.
- A candidate must obtain an address and pass an internet connectivity check.
- Existing NetworkManager profiles are retained.
- A failed candidate is deleted. The previous profile is restored when one was
  active; otherwise the setup hotspot returns with the same name and password.
- A verified candidate is saved with autoconnect enabled. The setup marker is
  removed so Chromium returns to the normal Screenify display.

## Install

Run on the Orange Pi:

```sh
sudo ./install.sh
```

The installer requires NetworkManager, `create_ap`, hostapd, dnsmasq, and the
Python cryptography package. It does not remove customer Wi-Fi profiles.

## Local preview

```sh
python3 screenify_wifi_setup.py --demo --port 8090
```

- Phone portal: `http://127.0.0.1:8090/`
- Physical display: `http://127.0.0.1:8090/display`
