#!/usr/bin/env python3
"""Screenify Wi-Fi provisioning and rollback service.

Android can send encrypted credentials over Bluetooth LE. When Screenify has
no usable Wi-Fi connection, the same built-in radio also becomes a temporary
WPA2 access point for iPhone captive-portal setup. The radio is returned to
NetworkManager before a candidate is tested, and existing customer profiles
are never removed.
"""

from __future__ import annotations

import argparse
import dataclasses
import ipaddress
import json
import logging
import os
import re
import secrets
import signal
import socket
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Iterable, Optional


LOG = logging.getLogger("screenify-wifi-setup")
SETUP_PROFILE = "screenify-setup"
MAX_BODY_BYTES = 16 * 1024
MAX_BRIDGE_STATE_BYTES = 512 * 1024
BLUETOOTH_SETUP_CODE_LENGTH = 10
EVENT_LOG_MAX_BYTES = 256 * 1024
EVENT_LOG_RETAIN_BYTES = 128 * 1024
CANDIDATE_PHASES = {
    "Preparing candidate Wi-Fi",
    "Switching from setup network to home Wi-Fi",
    "Connecting to candidate Wi-Fi",
    "Verifying internet access",
    "Recovering previous Wi-Fi",
}


def env_bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def device_suffix() -> str:
    for source in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
        try:
            value = re.sub(r"[^A-Fa-f0-9]", "", source.read_text()).upper()
            if len(value) >= 4:
                return value[-4:]
        except OSError:
            pass
    return socket.gethostname().encode("utf-8").hex().upper()[-4:].rjust(4, "0")


def load_or_create_password(state_dir: Path) -> str:
    configured = os.environ.get("SCREENIFY_WIFI_SETUP_PASSWORD", "").strip()
    if 8 <= len(configured) <= 63:
        return configured

    password_file = state_dir / "setup-password"
    try:
        existing = password_file.read_text(encoding="utf-8").strip()
        if 8 <= len(existing) <= 63:
            return existing
    except OSError:
        pass

    state_dir.mkdir(parents=True, exist_ok=True)
    generated = "SF-" + secrets.token_hex(5).upper()
    password_file.write_text(generated + "\n", encoding="utf-8")
    try:
        password_file.chmod(0o600)
    except OSError:
        pass
    return generated


@dataclass(frozen=True)
class Config:
    interface: str
    setup_ssid: str
    setup_password: str
    host: str
    port: int
    offline_grace_seconds: float
    connect_timeout_seconds: float
    handoff_delay_seconds: float
    poll_seconds: float
    state_dir: Path
    runtime_dir: Path
    web_dir: Path
    hold_existing: bool
    simulate: bool
    allow_private_test_clients: bool
    check_urls: tuple[str, ...]
    provisioning_transport: str = "auto"
    bridge_state_url: str = "http://127.0.0.1:8787/api/state"
    hotspot_enabled: bool = True
    hotspot_gateway: str = "192.168.12.1"
    hotspot_country: str = "US"
    hotspot_start_timeout_seconds: float = 22
    create_ap_path: str = "/usr/bin/create_ap"
    hotspot_stop_timeout_seconds: float = 18
    candidate_hard_timeout_seconds: float = 150
    curl_path: str = "/usr/bin/curl"

    @classmethod
    def from_env(cls) -> "Config":
        script_dir = Path(__file__).resolve().parent
        state_dir = Path(
            os.environ.get(
                "SCREENIFY_WIFI_SETUP_STATE_DIR",
                "/var/lib/screenify-wifi-setup",
            )
        )
        suffix = device_suffix()
        return cls(
            interface=os.environ.get("SCREENIFY_WIFI_INTERFACE", "wlan0"),
            setup_ssid=os.environ.get(
                "SCREENIFY_WIFI_SETUP_SSID", f"Screenify {suffix}"
            ),
            setup_password=load_or_create_password(state_dir),
            host=os.environ.get("SCREENIFY_WIFI_SETUP_HOST", "0.0.0.0"),
            port=int(os.environ.get("SCREENIFY_WIFI_SETUP_PORT", "80")),
            offline_grace_seconds=float(
                os.environ.get("SCREENIFY_WIFI_OFFLINE_GRACE_SECONDS", "180")
            ),
            connect_timeout_seconds=float(
                os.environ.get("SCREENIFY_WIFI_CONNECT_TIMEOUT_SECONDS", "50")
            ),
            handoff_delay_seconds=float(
                os.environ.get("SCREENIFY_WIFI_HANDOFF_DELAY_SECONDS", "1.25")
            ),
            poll_seconds=float(os.environ.get("SCREENIFY_WIFI_POLL_SECONDS", "5")),
            state_dir=state_dir,
            runtime_dir=Path(
                os.environ.get(
                    "SCREENIFY_WIFI_SETUP_RUNTIME_DIR",
                    "/run/screenify-wifi-setup",
                )
            ),
            web_dir=Path(
                os.environ.get("SCREENIFY_WIFI_SETUP_WEB_DIR", str(script_dir / "web"))
            ),
            hold_existing=env_bool("SCREENIFY_WIFI_HOLD_EXISTING", False),
            simulate=env_bool("SCREENIFY_WIFI_SIMULATE", False),
            allow_private_test_clients=env_bool(
                "SCREENIFY_WIFI_ALLOW_PRIVATE_TEST_CLIENTS", False
            ),
            check_urls=tuple(
                url.strip()
                for url in os.environ.get(
                    "SCREENIFY_WIFI_CHECK_URLS",
                    "http://connectivitycheck.gstatic.com/generate_204,"
                    "http://www.msftconnecttest.com/connecttest.txt",
                ).split(",")
                if url.strip()
            ),
            provisioning_transport=os.environ.get(
                "SCREENIFY_WIFI_SETUP_TRANSPORT", "auto"
            ).strip().lower(),
            bridge_state_url=os.environ.get(
                "SCREENIFY_BRIDGE_STATE_URL",
                "http://127.0.0.1:8787/api/state",
            ).strip(),
            hotspot_enabled=env_bool("SCREENIFY_WIFI_HOTSPOT_ENABLED", True),
            hotspot_gateway=os.environ.get(
                "SCREENIFY_WIFI_HOTSPOT_GATEWAY", "192.168.12.1"
            ).strip(),
            hotspot_country=os.environ.get(
                "SCREENIFY_WIFI_HOTSPOT_COUNTRY", "US"
            ).strip().upper(),
            hotspot_start_timeout_seconds=float(
                os.environ.get("SCREENIFY_WIFI_HOTSPOT_START_TIMEOUT_SECONDS", "22")
            ),
            create_ap_path=os.environ.get(
                "SCREENIFY_WIFI_CREATE_AP_PATH", "/usr/bin/create_ap"
            ).strip(),
            hotspot_stop_timeout_seconds=float(
                os.environ.get("SCREENIFY_WIFI_HOTSPOT_STOP_TIMEOUT_SECONDS", "18")
            ),
            candidate_hard_timeout_seconds=float(
                os.environ.get("SCREENIFY_WIFI_CANDIDATE_HARD_TIMEOUT_SECONDS", "150")
            ),
            curl_path=os.environ.get(
                "SCREENIFY_WIFI_CURL_PATH", "/usr/bin/curl"
            ).strip(),
        )


class NetworkError(RuntimeError):
    pass


def split_nmcli_terse(line: str) -> list[str]:
    """Split an nmcli --terse escaped line without losing escaped colons."""
    values: list[str] = []
    current: list[str] = []
    escaped = False
    for character in line.rstrip("\r\n"):
        if escaped:
            current.append(character)
            escaped = False
        elif character == "\\":
            escaped = True
        elif character == ":":
            values.append("".join(current))
            current = []
        else:
            current.append(character)
    if escaped:
        current.append("\\")
    values.append("".join(current))
    return values


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: N802
        return None


class NetworkController:
    def __init__(self, config: Config):
        self.config = config

    def _run(
        self,
        args: Iterable[str],
        *,
        timeout: float = 25,
        allow_failure: bool = False,
        action: str = "NetworkManager command",
    ) -> str:
        command = ["nmcli", *list(args)]
        environment = os.environ.copy()
        environment["LC_ALL"] = "C"
        try:
            result = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=environment,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise NetworkError(f"{action} could not run") from error
        if result.returncode and not allow_failure:
            detail = (result.stderr or result.stdout).strip().splitlines()
            safe_detail = detail[-1][:240] if detail else "unknown error"
            raise NetworkError(f"{action} failed: {safe_detail}")
        return result.stdout.strip()

    def _run_external(
        self,
        command: list[str],
        *,
        timeout: float = 8,
        allow_failure: bool = False,
        action: str,
    ) -> str:
        environment = os.environ.copy()
        environment["LC_ALL"] = "C"
        try:
            result = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=environment,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            if allow_failure:
                LOG.warning("%s could not run: %s", action, error)
                return ""
            raise NetworkError(f"{action} could not run") from error
        if result.returncode and not allow_failure:
            detail = (result.stderr or result.stdout).strip().splitlines()
            safe_detail = detail[-1][:240] if detail else "unknown error"
            raise NetworkError(f"{action} failed: {safe_detail}")
        return result.stdout.strip()

    def saved_wifi_profile_count(self) -> int:
        output = self._run(
            [
                "--terse",
                "--escape",
                "yes",
                "--fields",
                "NAME,TYPE",
                "connection",
                "show",
            ],
            action="listing saved Wi-Fi profiles",
        )
        count = 0
        for line in output.splitlines():
            fields = split_nmcli_terse(line)
            if len(fields) >= 2 and fields[0] != SETUP_PROFILE and fields[1] in {
                "802-11-wireless",
                "wifi",
            }:
                count += 1
        return count

    def active_uuid(self) -> str:
        value = self._run(
            ["--get-values", "GENERAL.CON-UUID", "device", "show", self.config.interface],
            allow_failure=True,
            action="reading the active Wi-Fi profile",
        ).strip()
        return "" if value in {"", "--"} else value

    def active_connection_name(self) -> str:
        value = self._run(
            ["--get-values", "GENERAL.CONNECTION", "device", "show", self.config.interface],
            allow_failure=True,
            action="reading the active Wi-Fi connection",
        ).strip()
        return "" if value in {"", "--"} else value

    def is_connected(self) -> bool:
        state = self._run(
            ["--get-values", "GENERAL.STATE", "device", "show", self.config.interface],
            allow_failure=True,
            action="checking Wi-Fi state",
        )
        return state.lstrip().startswith("100")

    def is_setup_active(self) -> bool:
        return self.active_connection_name() == SETUP_PROFILE

    def wifi_driver_name(self) -> str:
        device_path = Path("/sys/class/net") / self.config.interface / "device"
        for link in (device_path / "driver", device_path / "driver" / "module"):
            try:
                resolved = link.resolve(strict=True)
            except OSError:
                continue
            if resolved.name:
                return resolved.name.lower()
        return ""

    def scan_networks(self) -> list[dict[str, Any]]:
        output = self._run(
            [
                "--terse",
                "--escape",
                "yes",
                "--fields",
                "SSID,SIGNAL,SECURITY",
                "device",
                "wifi",
                "list",
                "ifname",
                self.config.interface,
                "--rescan",
                "yes",
            ],
            timeout=35,
            action="scanning Wi-Fi networks",
        )
        by_ssid: dict[str, dict[str, Any]] = {}
        for line in output.splitlines():
            fields = split_nmcli_terse(line)
            if len(fields) < 3:
                continue
            ssid = fields[0].strip()
            if not ssid or ssid == self.config.setup_ssid:
                continue
            try:
                signal = max(0, min(100, int(fields[1] or 0)))
            except ValueError:
                signal = 0
            security = ":".join(fields[2:]).strip()
            if security in {"", "--"}:
                security = "Open"
            candidate = {"ssid": ssid, "signal": signal, "security": security}
            if ssid not in by_ssid or signal > int(by_ssid[ssid]["signal"]):
                by_ssid[ssid] = candidate
        return sorted(by_ssid.values(), key=lambda item: (-item["signal"], item["ssid"]))

    def prepare_for_hotspot(self) -> None:
        """Hand the physical radio from NetworkManager to create_ap."""
        self._run(
            ["device", "disconnect", self.config.interface],
            allow_failure=True,
            action="disconnecting Wi-Fi before hotspot setup",
        )
        self._run(
            ["device", "set", self.config.interface, "managed", "no"],
            action="handing Wi-Fi to the setup hotspot",
        )

    def recover_after_hotspot(self) -> None:
        """Force AP-mode residue off the radio, then return it to NetworkManager."""
        # create_ap/hostapd normally restores an interface automatically. The
        # Orange Pi Zero 2W sprdwl driver can retain AP firmware state after
        # hostapd exits, causing every later nmcli station command to block.
        # Reassert the kernel interface type while NetworkManager is still out
        # of the way so the transition is deterministic on this hardware.
        self._run(
            ["device", "set", self.config.interface, "managed", "no"],
            timeout=5,
            allow_failure=True,
            action="holding Wi-Fi outside NetworkManager during radio reset",
        )
        self._run_external(
            ["ip", "link", "set", "dev", self.config.interface, "down"],
            allow_failure=True,
            action="bringing the setup radio down",
        )
        self._run_external(
            ["ip", "address", "flush", "dev", self.config.interface],
            allow_failure=True,
            action="removing the setup hotspot address",
        )
        self._run_external(
            ["iw", "dev", self.config.interface, "set", "type", "managed"],
            action="returning the Wi-Fi radio to managed mode",
        )
        self._run_external(
            ["ip", "link", "set", "dev", self.config.interface, "up"],
            allow_failure=True,
            action="bringing the Wi-Fi radio up",
        )
        self._run(
            ["device", "set", self.config.interface, "managed", "yes"],
            timeout=8,
            allow_failure=True,
            action="returning Wi-Fi to NetworkManager",
        )
        self._run(
            ["radio", "wifi", "on"],
            timeout=8,
            allow_failure=True,
            action="enabling Wi-Fi after setup hotspot",
        )
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            state = self._run(
                [
                    "--get-values",
                    "GENERAL.STATE",
                    "device",
                    "show",
                    self.config.interface,
                ],
                timeout=3,
                allow_failure=True,
                action="waiting for NetworkManager",
            ).strip().lower()
            if state and "unmanaged" not in state and not state.startswith("10 "):
                return
            time.sleep(0.25)

    def create_candidate(
        self, profile_name: str, ssid: str, password: str, security: str, hidden: bool
    ) -> None:
        self._run(
            [
                "connection",
                "add",
                "type",
                "wifi",
                "ifname",
                self.config.interface,
                "con-name",
                profile_name,
                "ssid",
                ssid,
            ],
            action="creating the candidate Wi-Fi profile",
        )
        settings = [
            "connection",
            "modify",
            "id",
            profile_name,
            "connection.autoconnect",
            "no",
            "802-11-wireless.hidden",
            "yes" if hidden else "no",
            "ipv4.method",
            "auto",
            "ipv6.method",
            "auto",
        ]
        normalized_security = security.upper()
        if password:
            settings.extend(
                [
                    "wifi-sec.key-mgmt",
                    "sae" if "SAE" in normalized_security or "WPA3" in normalized_security else "wpa-psk",
                    "wifi-sec.psk",
                    password,
                ]
            )
        self._run(settings, action="configuring the candidate Wi-Fi profile")

    def activate_profile(self, profile_name: str) -> None:
        self._run(
            ["connection", "up", "id", profile_name, "ifname", self.config.interface],
            timeout=max(40, self.config.connect_timeout_seconds),
            action="activating the candidate Wi-Fi profile",
        )

    def restore_profile(self, profile_uuid: str) -> bool:
        if not profile_uuid:
            return False
        try:
            self._run(
                ["connection", "up", "uuid", profile_uuid, "ifname", self.config.interface],
                timeout=45,
                action="restoring the previous Wi-Fi profile",
            )
            return self.is_connected()
        except NetworkError:
            return False

    def delete_profile(self, profile_name: str) -> None:
        self._run(
            ["connection", "delete", "id", profile_name],
            allow_failure=True,
            action="removing the failed candidate profile",
        )

    def finalize_profile(self, profile_name: str, ssid: str) -> None:
        safe_label = re.sub(r"[^A-Za-z0-9 _.-]", "", ssid).strip()[:32] or "Home"
        self._run(
            [
                "connection",
                "modify",
                "id",
                profile_name,
                "connection.id",
                f"Screenify WiFi - {safe_label}",
                "connection.autoconnect",
                "yes",
                "connection.autoconnect-priority",
                "100",
            ],
            action="saving the verified Wi-Fi profile",
        )

    def ipv4_addresses(self) -> list[str]:
        output = self._run(
            ["--get-values", "IP4.ADDRESS", "device", "show", self.config.interface],
            allow_failure=True,
            action="reading the assigned IP address",
        )
        return [
            line.strip()
            for line in output.splitlines()
            if line.strip() not in {"", "--"}
        ]

    def _url_reachable(self, url: str) -> bool:
        parsed = urllib.parse.urlparse(url)
        if not parsed.hostname:
            return False
        try:
            result = subprocess.run(
                [
                    self.config.curl_path,
                    "--silent",
                    "--show-error",
                    "--connect-timeout",
                    "4",
                    "--max-time",
                    "6",
                    "--range",
                    "0-1023",
                    "--user-agent",
                    "Screenify-WiFi-Check/1.0",
                    "--write-out",
                    "\n__SCREENIFY_STATUS__%{http_code}",
                    url,
                ],
                check=False,
                capture_output=True,
                timeout=8,
            )
        except (OSError, subprocess.TimeoutExpired):
            return False
        if result.returncode:
            return False
        marker = b"\n__SCREENIFY_STATUS__"
        body, separator, raw_status = result.stdout.rpartition(marker)
        if not separator:
            return False
        try:
            status = int(raw_status.strip())
        except ValueError:
            return False
        body = body[:1024]
        if parsed.path.endswith("generate_204"):
            return status == 204
        if parsed.hostname == "www.msftconnecttest.com":
            return status in {200, 206} and b"Microsoft Connect Test" in body
        return 200 <= status < 300

    def wait_for_internet(self, progress: Callable[[str], None]) -> bool:
        deadline = time.monotonic() + self.config.connect_timeout_seconds
        while time.monotonic() < deadline:
            if self.is_connected() and self.ipv4_addresses():
                progress("Verifying internet access")
                for url in self.config.check_urls:
                    try:
                        if self._url_reachable(url):
                            return True
                    except (OSError, urllib.error.URLError, ValueError):
                        continue
            time.sleep(2)
        return False

class SimulatedNetworkController(NetworkController):
    def __init__(self, config: Config):
        super().__init__(config)
        self.connected = False
        self.setup_active = False
        self.calls: list[tuple[str, Any]] = []
        self.internet_result = True
        self.saved_profiles = 0
        self.current_uuid = ""

    def saved_wifi_profile_count(self) -> int:
        return self.saved_profiles

    def active_uuid(self) -> str:
        return self.current_uuid

    def active_connection_name(self) -> str:
        return SETUP_PROFILE if self.setup_active else ("simulated-home" if self.connected else "")

    def is_connected(self) -> bool:
        return self.connected or self.setup_active

    def is_setup_active(self) -> bool:
        return self.setup_active

    def wifi_driver_name(self) -> str:
        return "simulated"

    def scan_networks(self) -> list[dict[str, Any]]:
        return [
            {"ssid": "Goofy Goobers", "signal": 92, "security": "WPA2"},
            {"ssid": "Screenify Guest", "signal": 74, "security": "WPA2 WPA3"},
            {"ssid": "Coffee Shop", "signal": 48, "security": "Open"},
        ]

    def prepare_for_hotspot(self) -> None:
        self.calls.append(("prepare_for_hotspot", None))
        self.connected = False

    def recover_after_hotspot(self) -> None:
        self.calls.append(("recover_after_hotspot", None))

    def create_candidate(self, profile_name, ssid, password, security, hidden) -> None:
        self.calls.append(("create_candidate", ssid))

    def activate_profile(self, profile_name: str) -> None:
        self.calls.append(("activate_profile", profile_name))
        self.setup_active = False
        self.connected = True

    def restore_profile(self, profile_uuid: str) -> bool:
        self.calls.append(("restore_profile", profile_uuid))
        self.setup_active = False
        self.connected = bool(profile_uuid)
        return self.connected

    def delete_profile(self, profile_name: str) -> None:
        self.calls.append(("delete_profile", profile_name))

    def finalize_profile(self, profile_name: str, ssid: str) -> None:
        self.calls.append(("finalize_profile", ssid))
        self.saved_profiles += 1

    def ipv4_addresses(self) -> list[str]:
        return ["192.168.1.25/24"] if self.connected else []

    def wait_for_internet(self, progress: Callable[[str], None]) -> bool:
        progress("Verifying internet access")
        return self.internet_result


class HotspotController:
    """Own a foreground create_ap process and its NetworkManager handoff."""

    READY_MARKERS = ("AP-ENABLED", "interface state UNINITIALIZED->ENABLED")

    def __init__(self, config: Config, network: NetworkController):
        self.config = config
        self.network = network
        self.lock = threading.RLock()
        self.process: Optional[subprocess.Popen[str]] = None
        self.ready_event = threading.Event()
        self.output_lines: list[str] = []
        self.simulated_active = False
        self.stop_lock = threading.Lock()

    def is_active(self) -> bool:
        if self.config.simulate:
            return self.simulated_active
        with self.lock:
            process = self.process
            return bool(
                process
                and process.poll() is None
                and self.ready_event.is_set()
            )

    def is_starting(self) -> bool:
        if self.config.simulate:
            return False
        with self.lock:
            process = self.process
            return bool(
                process
                and process.poll() is None
                and not self.ready_event.is_set()
            )

    def _read_output(self, process: subprocess.Popen[str]) -> None:
        if process.stdout is None:
            return
        for raw_line in process.stdout:
            line = raw_line.rstrip()
            safe_line = line.replace(self.config.setup_password, "[redacted]")
            with self.lock:
                self.output_lines.append(safe_line)
                self.output_lines = self.output_lines[-80:]
            if any(marker in line for marker in self.READY_MARKERS):
                self.ready_event.set()
            LOG.debug("Setup hotspot: %s", safe_line)

    def _safe_error(self) -> str:
        with self.lock:
            lines = [
                line
                for line in self.output_lines
                if line
                and not line.startswith(("Config dir:", "PID:", "hostapd command-line"))
            ]
        detail = lines[-1][:240] if lines else "create_ap exited before the hotspot was ready"
        return f"Setup hotspot failed: {detail}"

    def start(self) -> None:
        if not self.config.hotspot_enabled:
            return
        if self.config.simulate:
            self.network.prepare_for_hotspot()
            self.simulated_active = True
            return

        with self.lock:
            current = self.process
            if current and current.poll() is None:
                process = current
            else:
                self.ready_event.clear()
                self.output_lines.clear()
                self.network.prepare_for_hotspot()
                command = [
                    self.config.create_ap_path,
                    "-n",
                    "--redirect-to-localhost",
                    "--no-virt",
                    "--no-haveged",
                    "-w",
                    "2",
                    "--freq-band",
                    "2.4",
                    "--country",
                    self.config.hotspot_country,
                    "-g",
                    self.config.hotspot_gateway,
                    self.config.interface,
                ]
                try:
                    process = subprocess.Popen(
                        command,
                        stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        bufsize=1,
                        start_new_session=True,
                        env={**os.environ, "LC_ALL": "C"},
                    )
                except OSError as error:
                    self.network.recover_after_hotspot()
                    raise NetworkError("Setup hotspot could not start") from error
                self.process = process
                threading.Thread(
                    target=self._read_output,
                    args=(process,),
                    name="wifi-hotspot-output",
                    daemon=True,
                ).start()
                try:
                    assert process.stdin is not None
                    process.stdin.write(
                        f"{self.config.setup_ssid}\n{self.config.setup_password}\n"
                    )
                    process.stdin.flush()
                    process.stdin.close()
                except (BrokenPipeError, OSError) as error:
                    self.stop()
                    raise NetworkError("Setup hotspot rejected its configuration") from error

        deadline = time.monotonic() + self.config.hotspot_start_timeout_seconds
        while time.monotonic() < deadline:
            if self.ready_event.wait(0.2):
                LOG.info("Setup hotspot %s is ready", self.config.setup_ssid)
                return
            if process.poll() is not None:
                break
        error = self._safe_error()
        self.stop()
        raise NetworkError(error)

    def stop(self) -> None:
        if self.config.simulate:
            if self.simulated_active:
                self.simulated_active = False
                self.network.recover_after_hotspot()
            return

        with self.stop_lock:
            with self.lock:
                process = self.process
            had_hotspot_process = process is not None
            if process and process.poll() is None:
                # create_ap's supported stop contract is SIGUSR1, exposed by
                # `create_ap --stop <interface>`. That path runs its complete
                # hostapd/dnsmasq/IP cleanup before the parent exits.
                try:
                    subprocess.run(
                        [
                            self.config.create_ap_path,
                            "--stop",
                            self.config.interface,
                        ],
                        check=False,
                        capture_output=True,
                        text=True,
                        timeout=6,
                        env={**os.environ, "LC_ALL": "C"},
                    )
                except (OSError, subprocess.TimeoutExpired) as error:
                    LOG.warning("create_ap stop command did not complete: %s", error)

                try:
                    process.wait(timeout=self.config.hotspot_stop_timeout_seconds)
                except subprocess.TimeoutExpired:
                    LOG.error(
                        "create_ap did not exit after its supported stop command; "
                        "forcing cleanup"
                    )
                    try:
                        process.send_signal(signal.SIGUSR1)
                    except OSError:
                        pass
                    try:
                        process.wait(timeout=4)
                    except subprocess.TimeoutExpired:
                        try:
                            os.killpg(process.pid, signal.SIGTERM)
                            process.wait(timeout=3)
                        except (OSError, subprocess.TimeoutExpired):
                            try:
                                os.killpg(process.pid, signal.SIGKILL)
                            except OSError:
                                pass
                            try:
                                process.wait(timeout=2)
                            except subprocess.TimeoutExpired:
                                LOG.error("create_ap process could not be reaped")
            with self.lock:
                self.process = None
                self.ready_event.clear()
            if had_hotspot_process:
                self.network.recover_after_hotspot()
                LOG.info("Setup hotspot stopped; Wi-Fi returned to NetworkManager")

class ProvisioningApp:
    def __init__(
        self,
        config: Config,
        network: Optional[NetworkController] = None,
        hotspot: Optional[HotspotController] = None,
    ):
        self.config = config
        self.network = network or (
            SimulatedNetworkController(config) if config.simulate else NetworkController(config)
        )
        self.hotspot = hotspot or HotspotController(config, self.network)
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.csrf_token = secrets.token_urlsafe(24)
        self.cached_networks: list[dict[str, Any]] = []
        self.previous_uuid = ""
        self.offline_since: Optional[float] = None
        self.worker: Optional[threading.Thread] = None
        self.watchdog_thread: Optional[threading.Thread] = None
        self.candidate_started_at = 0.0
        self.fatal_event = threading.Event()
        self.hotspot_retry_after = 0.0
        self.hotspot_last_error = ""
        self.transport = self._resolve_transport()
        self.state: dict[str, Any] = {
            "mode": "starting",
            "phase": "Starting Wi-Fi service",
            "detail": "",
            "error": "",
            "jobId": "",
            "connectedSsid": "",
        }
        self.config.state_dir.mkdir(parents=True, exist_ok=True)
        self.config.runtime_dir.mkdir(parents=True, exist_ok=True)
        self._load_public_state()

    def _resolve_transport(self) -> str:
        configured = self.config.provisioning_transport
        if configured in {"auto", "bluetooth", "ble"}:
            return "bluetooth"
        LOG.warning(
            "Provisioning transport %r is no longer supported; using Bluetooth LE",
            configured,
        )
        return "bluetooth"

    @property
    def marker_path(self) -> Path:
        return self.config.runtime_dir / "setup-mode"

    @property
    def trigger_path(self) -> Path:
        return self.config.runtime_dir / "enter-setup"

    def _load_public_state(self) -> None:
        path = self.config.state_dir / "state.json"
        try:
            stored = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        for key, limit in (
            ("mode", 32),
            ("phase", 160),
            ("detail", 500),
            ("error", 500),
            ("jobId", 64),
            ("connectedSsid", 128),
        ):
            if key in stored:
                self.state[key] = str(stored.get(key, ""))[:limit]

    def _persist_public_state(self) -> None:
        payload = {
            "mode": self.state.get("mode", ""),
            "phase": self.state.get("phase", ""),
            "detail": self.state.get("detail", ""),
            "error": self.state.get("error", ""),
            "jobId": self.state.get("jobId", ""),
            "connectedSsid": self.state.get("connectedSsid", ""),
            "updatedAt": int(time.time()),
        }
        temporary = self.config.state_dir / "state.json.tmp"
        destination = self.config.state_dir / "state.json"
        temporary.write_text(json.dumps(payload), encoding="utf-8")
        temporary.replace(destination)

    def _append_event(self) -> None:
        path = self.config.state_dir / "events.log"
        event = {
            "at": int(time.time()),
            "mode": self.state.get("mode", ""),
            "phase": self.state.get("phase", ""),
            "detail": self.state.get("detail", ""),
            "error": self.state.get("error", ""),
            "jobId": self.state.get("jobId", ""),
        }
        try:
            if path.exists() and path.stat().st_size >= EVENT_LOG_MAX_BYTES:
                raw = path.read_bytes()[-EVENT_LOG_RETAIN_BYTES:]
                newline = raw.find(b"\n")
                if newline >= 0:
                    raw = raw[newline + 1 :]
                temporary = self.config.state_dir / "events.log.tmp"
                temporary.write_bytes(raw)
                temporary.replace(path)
            with path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(event, ensure_ascii=False) + "\n")
        except OSError as error:
            LOG.warning("Could not persist Wi-Fi phase diagnostic: %s", error)

    def _set_state(self, **changes: Any) -> None:
        with self.lock:
            old_event_state = tuple(
                self.state.get(key, "")
                for key in ("mode", "phase", "error", "jobId")
            )
            self.state.update(changes)
            if self.state["mode"] == "setup":
                self.marker_path.touch(exist_ok=True)
            else:
                try:
                    self.marker_path.unlink()
                except FileNotFoundError:
                    pass
            self._persist_public_state()
            new_event_state = tuple(
                self.state.get(key, "")
                for key in ("mode", "phase", "error", "jobId")
            )
            if new_event_state != old_event_state:
                self._append_event()

    def start(self) -> None:
        if self.watchdog_thread and self.watchdog_thread.is_alive():
            return
        # Recover cleanly if the service or board lost power while create_ap
        # had NetworkManager's radio marked unmanaged.
        if not self.network.is_connected():
            try:
                self.network.recover_after_hotspot()
            except NetworkError as error:
                LOG.warning("Initial Wi-Fi ownership recovery: %s", error)
        if self.network.is_setup_active():
            self._set_state(mode="setup", phase="Ready for Wi-Fi setup")
        elif self.network.is_connected():
            self._set_state(mode="online", phase="Connected", detail="")
        else:
            self._set_state(mode="waiting", phase="Looking for saved Wi-Fi")
        self.watchdog_thread = threading.Thread(
            target=self._watchdog,
            name="wifi-watchdog",
            daemon=True,
        )
        self.watchdog_thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        try:
            self.hotspot.stop()
        except Exception as error:
            LOG.exception("Stopping setup hotspot failed: %s", error)
        watchdog = self.watchdog_thread
        if (
            watchdog
            and watchdog.is_alive()
            and watchdog is not threading.current_thread()
        ):
            watchdog.join(timeout=max(2, self.config.poll_seconds + 1))

    def _sync_hotspot(self) -> None:
        should_run = (
            self.config.hotspot_enabled
            and self.state.get("mode") == "setup"
            and not self.network.is_connected()
        )
        if not should_run:
            if self.hotspot.is_active() or self.hotspot.is_starting():
                self.hotspot.stop()
            return
        if self.hotspot.is_active() or self.hotspot.is_starting():
            return
        if time.monotonic() < self.hotspot_retry_after:
            return
        self._set_state(
            mode="setup",
            phase="Starting iPhone setup network",
            detail=f"Preparing {self.config.setup_ssid}",
        )
        try:
            self.hotspot.start()
            self.hotspot_retry_after = 0
            changes: dict[str, Any] = {
                "mode": "setup",
                "phase": "Ready for Wi-Fi setup",
                "detail": "Use iPhone Wi-Fi Settings or the Screenify Android app.",
            }
            if self.state.get("error") == self.hotspot_last_error:
                changes["error"] = ""
            self.hotspot_last_error = ""
            self._set_state(**changes)
        except NetworkError as error:
            self.hotspot_retry_after = time.monotonic() + 10
            self.hotspot_last_error = str(error)
            LOG.warning("Setup hotspot: %s", error)
            self._set_state(
                mode="setup",
                phase="Bluetooth setup is ready",
                detail="The iPhone setup network will retry automatically.",
                error=str(error),
            )

    def _watchdog(self) -> None:
        while not self.stop_event.is_set():
            try:
                if self.trigger_path.exists():
                    try:
                        self.trigger_path.unlink()
                    except FileNotFoundError:
                        pass
                    self.enter_setup_mode("Setup requested on this device")
                with self.lock:
                    testing = self.state.get("phase") in CANDIDATE_PHASES
                    worker_alive = bool(self.worker and self.worker.is_alive())
                    candidate_elapsed = (
                        time.monotonic() - self.candidate_started_at
                        if self.candidate_started_at
                        else 0
                    )
                if (
                    testing
                    and worker_alive
                    and candidate_elapsed > self.config.candidate_hard_timeout_seconds
                ):
                    LOG.critical(
                        "Candidate handoff exceeded its %.1f second hard deadline; "
                        "restarting the provisioning service",
                        self.config.candidate_hard_timeout_seconds,
                    )
                    self._set_state(
                        mode="error",
                        phase="Wi-Fi handoff timed out",
                        detail="The Wi-Fi service is restarting automatically.",
                        error=(
                            "Wi-Fi setup exceeded its safety deadline and was "
                            "automatically reset."
                        ),
                    )
                    self.fatal_event.set()
                    return
                if testing and not worker_alive:
                    LOG.error(
                        "Candidate worker exited without completing its state transition"
                    )
                    self._set_state(
                        mode="setup",
                        phase="Ready for Wi-Fi setup",
                        detail="The previous attempt was safely reset. Please try again.",
                        error="Wi-Fi setup stopped unexpectedly before it completed.",
                    )
                    self.stop_event.wait(min(self.config.poll_seconds, 1.5))
                    continue
                if testing:
                    self.stop_event.wait(min(self.config.poll_seconds, 1.5))
                    continue
                if self.state.get("mode") == "setup":
                    # Setup remains open until a candidate is verified. This
                    # also makes "Change Wi-Fi" work while the old network and
                    # phone connection are still healthy.
                    self._sync_hotspot()
                    self.stop_event.wait(self.config.poll_seconds)
                    continue
                if self.network.is_setup_active():
                    self.offline_since = None
                    with self.lock:
                        if self.state.get("mode") != "setup":
                            self._set_state(mode="setup", phase="Ready for Wi-Fi setup")
                elif self.network.is_connected():
                    self.offline_since = None
                    with self.lock:
                        # A local setup request may arrive while the network
                        # probe above is running. Never overwrite that newer
                        # setup state with a stale "online" observation.
                        if self.state.get("mode") != "setup" and self.state.get("mode") != "online":
                            self._set_state(
                                mode="online",
                                phase="Connected",
                                detail="",
                                error="",
                            )
                else:
                    if self.offline_since is None:
                        self.offline_since = time.monotonic()
                    saved_count = self.network.saved_wifi_profile_count()
                    grace = self.config.offline_grace_seconds if saved_count else 0
                    elapsed = time.monotonic() - self.offline_since
                    if elapsed >= grace:
                        self.enter_setup_mode(
                            "No saved Wi-Fi" if not saved_count else "Saved Wi-Fi unavailable"
                        )
                    else:
                        remaining = max(0, int(grace - elapsed))
                        self._set_state(
                            mode="waiting",
                            phase="Trying saved Wi-Fi",
                            detail=f"Setup mode will start in {remaining} seconds",
                        )
            except NetworkError as error:
                LOG.warning("Wi-Fi watchdog: %s", error)
                self._set_state(mode="error", phase="Wi-Fi service needs attention", error=str(error))
            self.stop_event.wait(self.config.poll_seconds)

    def _connected_screenify_client(self) -> str:
        if not self.config.bridge_state_url:
            return ""
        try:
            request = urllib.request.Request(
                self.config.bridge_state_url,
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(request, timeout=1.5) as response:
                raw = response.read(MAX_BRIDGE_STATE_BYTES + 1)
                if len(raw) > MAX_BRIDGE_STATE_BYTES:
                    return ""
                payload = json.loads(raw.decode("utf-8"))
        except (
            OSError,
            TimeoutError,
            UnicodeDecodeError,
            json.JSONDecodeError,
            urllib.error.URLError,
        ):
            return ""
        if not isinstance(payload, dict):
            return ""
        connection = payload.get("connection")
        if not isinstance(connection, dict) or not connection.get("connected"):
            return ""
        return (
            str(connection.get("clientName", "")).strip()[:80]
            or str(payload.get("activeClientName", "")).strip()[:80]
            or "Your phone"
        )

    def enter_setup_mode(self, reason: str, *, preserve_error: bool = False) -> None:
        if self.state.get("mode") == "setup":
            self._set_state(mode="setup", phase="Ready for Wi-Fi setup", detail=reason)
            return
        previous = self.network.active_uuid()
        if previous:
            self.previous_uuid = previous
        self._set_state(mode="starting", phase="Preparing Wi-Fi setup", detail=reason)
        try:
            self.cached_networks = self.network.scan_networks()
        except NetworkError as error:
            LOG.warning("Wi-Fi scan before setup failed: %s", error)
        self.offline_since = None
        changes: dict[str, Any] = {
            "mode": "setup",
            "phase": "Ready for Wi-Fi setup",
            "detail": reason,
        }
        if not preserve_error:
            changes["error"] = ""
        self._set_state(**changes)
        self._sync_hotspot()

    def _client_may_see_secret(self, client_address: str) -> bool:
        try:
            address = ipaddress.ip_address(client_address)
        except ValueError:
            return False
        if address.is_loopback:
            return True
        if self.config.allow_private_test_clients and address.is_private:
            return True
        if not self.hotspot.is_active():
            return False
        try:
            hotspot_network = ipaddress.ip_network(
                f"{self.config.hotspot_gateway}/24", strict=False
            )
        except ValueError:
            return False
        return address in hotspot_network

    def public_status(self, client_address: str) -> dict[str, Any]:
        with self.lock:
            status = dict(self.state)
        status.update(
            {
                "deviceName": "Screenify",
                "holdExisting": self.config.hold_existing,
                "transport": self.transport,
            }
        )
        if status["mode"] == "setup" and self._client_may_see_secret(client_address):
            status["setup"] = {
                "transport": "bluetooth",
                "deviceName": self.config.setup_ssid,
                "code": self.bluetooth_setup_code(),
                "token": self.csrf_token,
                "hotspot": {
                    "enabled": self.config.hotspot_enabled,
                    "active": self.hotspot.is_active(),
                    "ssid": self.config.setup_ssid,
                    "password": self.config.setup_password,
                    "gateway": self.config.hotspot_gateway,
                },
            }
            status["networks"] = list(self.cached_networks)
        return status

    def bluetooth_setup_code(self) -> str:
        compact = re.sub(r"[^A-Za-z0-9]", "", self.config.setup_password).upper()
        return compact[-BLUETOOTH_SETUP_CODE_LENGTH:].rjust(
            BLUETOOTH_SETUP_CODE_LENGTH,
            "0",
        )

    def bluetooth_status(self) -> dict[str, Any]:
        with self.lock:
            state = dict(self.state)
            networks = list(self.cached_networks)
        addresses: list[str] = []
        if state.get("mode") == "online":
            try:
                addresses = self.network.ipv4_addresses()
            except NetworkError:
                pass
        return {
            "mode": state.get("mode", "starting"),
            "phase": state.get("phase", ""),
            "detail": state.get("detail", ""),
            "error": state.get("error", ""),
            "device": self.config.setup_ssid,
            "networks": [
                {
                    "ssid": str(item.get("ssid", ""))[:32],
                    "signal": int(item.get("signal", 0)),
                    "security": str(item.get("security", "Open"))[:32],
                }
                for item in networks[:8]
            ],
            "ip": addresses[0].split("/", 1)[0] if addresses else "",
        }

    def request_bluetooth_connection(self, payload: dict[str, Any]) -> str:
        code = re.sub(r"[^A-Za-z0-9]", "", str(payload.pop("code", ""))).upper()
        if not secrets.compare_digest(code, self.bluetooth_setup_code()):
            raise PermissionError("The setup code does not match the Screenify display.")
        if self.state.get("mode") != "setup":
            raise RuntimeError("Screenify is not currently in Wi-Fi setup mode.")
        return self.request_connection(payload, self.csrf_token)

    def validate_connection_request(self, payload: dict[str, Any]) -> dict[str, Any]:
        ssid = str(payload.get("ssid", "")).strip()
        password = str(payload.get("password", ""))
        security = str(payload.get("security", "WPA2")).strip()[:64]
        hidden = bool(payload.get("hidden", False))
        if not ssid or len(ssid.encode("utf-8")) > 32:
            raise ValueError("Choose a Wi-Fi network or enter a valid network name.")
        if "OPEN" not in security.upper() and not (8 <= len(password) <= 63):
            raise ValueError("The Wi-Fi password must be between 8 and 63 characters.")
        if len(password) > 63:
            raise ValueError("The Wi-Fi password is too long.")
        return {"ssid": ssid, "password": password, "security": security, "hidden": hidden}

    def request_connection(self, payload: dict[str, Any], token: str) -> str:
        if not secrets.compare_digest(token, self.csrf_token):
            raise PermissionError("Refresh the setup page and try again.")
        candidate = self.validate_connection_request(payload)
        with self.lock:
            if self.worker and self.worker.is_alive():
                raise RuntimeError("Screenify is already testing a Wi-Fi connection.")
            job_id = uuid.uuid4().hex
            self.candidate_started_at = time.monotonic()
            self._set_state(
                mode="setup",
                phase="Preparing candidate Wi-Fi",
                detail=f'Testing “{candidate["ssid"]}”',
                error="",
                jobId=job_id,
            )
            self.worker = threading.Thread(
                target=self._connect_candidate,
                args=(job_id, candidate),
                name="wifi-candidate",
                daemon=True,
            )
            self.worker.start()
        return job_id

    def _progress(self, phase: str) -> None:
        self._set_state(mode="setup", phase=phase)

    def _connect_candidate(self, job_id: str, candidate: dict[str, Any]) -> None:
        ssid = candidate["ssid"]
        if self.config.hold_existing:
            self._set_state(
                mode="setup",
                phase="Safe test complete",
                detail=f'“{ssid}” passed form validation. Existing Wi-Fi was not changed.',
                jobId=job_id,
            )
            return

        profile_name = f"screenify-candidate-{job_id[:8]}"
        previous_uuid = self.previous_uuid
        try:
            # Give the phone time to receive the HTTP 202 response before the
            # access point is intentionally taken down for candidate testing.
            if self.config.handoff_delay_seconds > 0:
                self.stop_event.wait(self.config.handoff_delay_seconds)
            if self.hotspot.is_active() or self.hotspot.is_starting():
                self._progress("Switching from setup network to home Wi-Fi")
                self.hotspot.stop()
            self.network.create_candidate(
                profile_name,
                ssid,
                candidate["password"],
                candidate["security"],
                candidate["hidden"],
            )
            self._progress("Connecting to candidate Wi-Fi")
            self.network.activate_profile(profile_name)
            verified = self.network.wait_for_internet(self._progress)
            if not verified:
                raise NetworkError("Connected to Wi-Fi, but internet access could not be verified.")
            self.network.finalize_profile(profile_name, ssid)
            self._set_state(
                mode="online",
                phase="Wi-Fi connected",
                detail=f'Screenify is connected to “{ssid}”.',
                error="",
                connectedSsid=ssid,
                jobId=job_id,
            )
            LOG.info("Verified and saved a new Wi-Fi profile")
        except Exception as caught_error:
            if isinstance(caught_error, NetworkError):
                error = caught_error
                LOG.warning("Candidate Wi-Fi failed validation: %s", error)
            else:
                LOG.exception("Candidate Wi-Fi worker failed unexpectedly")
                error = NetworkError(
                    "Wi-Fi setup hit an internal error and was safely reset."
                )
            try:
                self.network.delete_profile(profile_name)
            except NetworkError as cleanup_error:
                LOG.warning("Could not remove failed candidate: %s", cleanup_error)
            self._progress("Recovering previous Wi-Fi")
            try:
                restored = self.network.restore_profile(previous_uuid)
            except NetworkError as restore_error:
                LOG.warning("Could not restore previous Wi-Fi: %s", restore_error)
                restored = False
            if restored:
                self._set_state(
                    mode="setup",
                    phase="Ready for Wi-Fi setup",
                    detail=(
                        "That network did not connect. The previous Wi-Fi was "
                        "restored; correct the details and try again."
                    ),
                    error=str(error),
                    jobId=job_id,
                )
                return
            try:
                self.enter_setup_mode("Candidate Wi-Fi failed; try again", preserve_error=True)
                self._set_state(error=str(error), jobId=job_id)
            except NetworkError as hotspot_error:
                self._set_state(
                    mode="error",
                    phase="Wi-Fi recovery failed",
                    detail="Restart Screenify to retry setup mode.",
                    error=f"{error} {hotspot_error}",
                    jobId=job_id,
                )

class PortalServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, handler, app: ProvisioningApp):
        super().__init__(address, handler)
        self.app = app


class PortalHandler(BaseHTTPRequestHandler):
    server: PortalServer

    def log_message(self, format_string: str, *args: Any) -> None:
        LOG.debug("Portal request: " + format_string, *args)

    @property
    def app(self) -> ProvisioningApp:
        return self.server.app

    def _headers(self, status: int, content_type: str, length: int = 0) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
        )
        if length:
            self.send_header("Content-Length", str(length))
        self.end_headers()

    def _send(self, status: int, content_type: str, body: bytes) -> None:
        self._headers(status, content_type, len(body))
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        self._send(
            status,
            "application/json; charset=utf-8",
            json.dumps(payload, separators=(",", ":")).encode("utf-8"),
        )

    def _redirect(self, location: str = "/") -> None:
        self.send_response(HTTPStatus.FOUND)
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _serve_file(self, name: str, content_type: str) -> None:
        try:
            body = (self.app.config.web_dir / name).read_bytes()
        except OSError:
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": "Portal asset is missing."})
            return
        self._send(HTTPStatus.OK, content_type, body)

    def do_HEAD(self) -> None:  # noqa: N802
        self.do_GET()

    def do_GET(self) -> None:  # noqa: N802
        path = urllib.parse.urlparse(self.path).path
        client = self.client_address[0]
        if path == "/api/status":
            self._json(HTTPStatus.OK, self.app.public_status(client))
            return
        if path == "/setup.css":
            self._serve_file("setup.css", "text/css; charset=utf-8")
            return
        if path == "/setup.js":
            self._serve_file("setup.js", "application/javascript; charset=utf-8")
            return
        if path in {"/", "/display"}:
            self._serve_file("index.html", "text/html; charset=utf-8")
            return
        if self.app.state.get("mode") == "setup":
            self._redirect("/")
            return
        self._json(HTTPStatus.NOT_FOUND, {"error": "Not found"})

    def do_POST(self) -> None:  # noqa: N802
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/setup":
            try:
                local_request = ipaddress.ip_address(
                    self.client_address[0]
                ).is_loopback
            except ValueError:
                local_request = False
            if not local_request:
                self._json(HTTPStatus.FORBIDDEN, {"error": "Local request required."})
                return
            self.app.enter_setup_mode("Wi-Fi change requested from the Screenify app")
            self._json(HTTPStatus.ACCEPTED, {"ok": True})
            return
        if path != "/api/connect":
            self._json(HTTPStatus.NOT_FOUND, {"error": "Not found"})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY_BYTES:
            self._json(HTTPStatus.BAD_REQUEST, {"error": "Invalid request."})
            return
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            job_id = self.app.request_connection(
                payload,
                self.headers.get("X-Screenify-Token", ""),
            )
        except json.JSONDecodeError:
            self._json(HTTPStatus.BAD_REQUEST, {"error": "Invalid request."})
            return
        except ValueError as error:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(error)})
            return
        except PermissionError as error:
            self._json(HTTPStatus.FORBIDDEN, {"error": str(error)})
            return
        except RuntimeError as error:
            self._json(HTTPStatus.CONFLICT, {"error": str(error)})
            return
        self._json(HTTPStatus.ACCEPTED, {"ok": True, "jobId": job_id})


def serve(config: Config) -> None:
    app = ProvisioningApp(config)
    app.start()
    bluetooth_server = None
    if app.transport == "bluetooth" and not config.simulate:
        try:
            from screenify_wifi_ble import BluetoothProvisioningServer

            bluetooth_server = BluetoothProvisioningServer(app)
            bluetooth_server.start()
        except Exception as error:
            LOG.exception("Bluetooth Wi-Fi setup could not start")
            app._set_state(
                mode="error",
                phase="Bluetooth setup needs attention",
                error=str(error),
            )
    server = PortalServer((config.host, config.port), PortalHandler, app)
    LOG.info("Screenify Wi-Fi portal listening on %s:%s", config.host, config.port)
    shutdown_event = threading.Event()
    previous_signal_handlers: dict[int, Any] = {}

    def request_shutdown(signum, _frame) -> None:
        LOG.info("Stopping Wi-Fi setup service after signal %s", signum)
        shutdown_event.set()

    try:
        for signum in (signal.SIGTERM, signal.SIGINT):
            previous_signal_handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, request_shutdown)
    except ValueError:
        # Demo/test servers may run outside Python's main thread.
        previous_signal_handlers.clear()

    server.timeout = 0.5
    try:
        while not shutdown_event.is_set() and not app.fatal_event.is_set():
            server.handle_request()
    finally:
        app.stop()
        if bluetooth_server is not None:
            bluetooth_server.stop()
        server.server_close()
        for signum, handler in previous_signal_handlers.items():
            signal.signal(signum, handler)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Screenify Wi-Fi setup service")
    parser.add_argument(
        "--demo",
        action="store_true",
        help="serve a simulated portal without running NetworkManager commands",
    )
    parser.add_argument("--port", type=int, help="override the HTTP port")
    parser.add_argument(
        "--trigger-setup",
        action="store_true",
        help="ask the running service to enter setup mode on its next poll",
    )
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("SCREENIFY_WIFI_LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(message)s",
    )
    args = parse_args()
    if args.demo:
        demo_root = Path(tempfile.gettempdir()) / "screenify-wifi-setup-demo"
        os.environ.setdefault(
            "SCREENIFY_WIFI_SETUP_STATE_DIR", str(demo_root / "state")
        )
        os.environ.setdefault(
            "SCREENIFY_WIFI_SETUP_RUNTIME_DIR", str(demo_root / "run")
        )
        os.environ.setdefault("SCREENIFY_WIFI_SETUP_SSID", "Screenify Setup DEMO")
        os.environ.setdefault("SCREENIFY_WIFI_SETUP_PASSWORD", "SF-DEMO12345")
    config = Config.from_env()
    if args.trigger_setup:
        config.runtime_dir.mkdir(parents=True, exist_ok=True)
        (config.runtime_dir / "enter-setup").touch(exist_ok=True)
        print("SCREENIFY_WIFI_SETUP_TRIGGERED")
        return
    if args.demo:
        config = dataclasses.replace(
            config,
            simulate=True,
            hold_existing=True,
            host="127.0.0.1",
            port=args.port or 8090,
            offline_grace_seconds=0,
        )
    elif args.port:
        config = dataclasses.replace(config, port=args.port)
    serve(config)


if __name__ == "__main__":
    main()
